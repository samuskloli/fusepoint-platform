<?php
/**
 * Plugin Name: CP Email Two-Factor Auth
 * Description: Authentification à deux facteurs par email (OTP à usage unique) en deux étapes.
 * Version: 1.1.0
 * Author: Chaque-Pas Compte
 * Requires at least: 5.8
 * Requires PHP: 7.2
 * Text Domain: cp-email-2fa
 */

if (!defined('ABSPATH')) exit;

class CP_Email_Two_Factor_Auth {
    const META_ENABLED = 'cp_email_2fa_enabled';
    const OPTION_VERSION = 'cp_email_2fa_version';

    public function __construct() {
        // Étape 1: intercepter la connexion et envoyer le code, puis rediriger vers la page de vérification
        add_filter('authenticate', [$this, 'authenticate_2fa'], 30, 3);
        // Étape 2: page de vérification dédiée sur wp-login.php?action=cp_email_2fa
        add_action('login_form_cp_email_2fa', [$this, 'render_verify_form']);
        add_action('login_init', [$this, 'handle_verify_submission']);

        // Profil utilisateur: bascule d'activation
        add_action('show_user_profile', [$this, 'render_user_profile']);
        add_action('edit_user_profile', [$this, 'render_user_profile']);
        add_action('personal_options_update', [$this, 'save_user_profile']);
        add_action('edit_user_profile_update', [$this, 'save_user_profile']);
        add_action('admin_init', [$this, 'maybe_admin_notices']);

        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_uninstall_hook(__FILE__, [__CLASS__, 'uninstall']);
    }

    public static function activate() {
        update_option(self::OPTION_VERSION, '1.1.0');
    }

    public static function uninstall() {
        delete_option(self::OPTION_VERSION);
    }

    private function is_enabled_for_user($user_id) {
        return (bool) get_user_meta($user_id, self::META_ENABLED, true);
    }

    public function authenticate_2fa($user, $username, $password) {
        // Ne pas interférer avec la page de vérification elle-même
        if (isset($_REQUEST['action']) && $_REQUEST['action'] === 'cp_email_2fa') {
            return $user;
        }
        if ($user instanceof WP_User) {
            if ($this->is_enabled_for_user($user->ID)) {
                // Envoyer le code et rediriger vers la page de vérification
                $send = $this->send_code($user);
                if ($send !== true) {
                    return $send instanceof WP_Error ? $send : new WP_Error('cp_email_2fa_send_failed', esc_html__('Échec de l’envoi du code par email.', 'cp-email-2fa'));
                }
                $remember = !empty($_POST['rememberme']);
                $redirect_to = isset($_REQUEST['redirect_to']) ? esc_url_raw($_REQUEST['redirect_to']) : admin_url();
                $token = wp_generate_password(20, false);
                set_transient('cp_email_2fa_ctx_' . $user->ID, [
                    'token_hash'  => wp_hash($token),
                    'remember'    => (bool) $remember,
                    'redirect_to' => $redirect_to,
                ], 10 * 60);
                $verify_url = add_query_arg([
                    'action'      => 'cp_email_2fa',
                    'uid'         => $user->ID,
                    'token'       => $token,
                    'redirect_to' => $redirect_to,
                ], wp_login_url());
                wp_safe_redirect($verify_url);
                exit;
            }
        }
        return $user;
    }

    private function send_code(WP_User $user) {
        $user_id = $user->ID;
        $last = get_transient('cp_email_2fa_last_sent_' . $user_id);
        if ($last) {
            $wait = 60 - (time() - (int)$last);
            if ($wait > 0) {
                return new WP_Error('cp_email_2fa_rate', sprintf(esc_html__('Un code vient d’être envoyé. Réessayez dans %d secondes.', 'cp-email-2fa'), $wait));
            }
        }
        $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        set_transient('cp_email_2fa_code_' . $user_id, $code, 10 * 60);
        set_transient('cp_email_2fa_last_sent_' . $user_id, time(), 60);

        $site = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject = sprintf('[%s] %s', $site, esc_html__('Votre code de connexion', 'cp-email-2fa'));
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        $message = sprintf(
            "%s\n\n%s: %s\n%s: %s\n%s\n\n%s\n",
            esc_html__('Voici votre code de connexion à usage unique.', 'cp-email-2fa'),
            esc_html__('Code', 'cp-email-2fa'), $code,
            esc_html__('Valide jusqu’à', 'cp-email-2fa'), date_i18n('d/m/Y H:i', time() + 10 * 60),
            sprintf(esc_html__('Reçu depuis: %s', 'cp-email-2fa'), $ip),
            esc_html__('Si vous n’êtes pas à l’origine de cette demande, ignorez ce message.', 'cp-email-2fa')
        );
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        $ok = wp_mail($user->user_email, $subject, $message, $headers);
        if (!$ok) {
            delete_transient('cp_email_2fa_code_' . $user_id);
            delete_transient('cp_email_2fa_last_sent_' . $user_id);
            return new WP_Error('cp_email_2fa_send_failed', esc_html__('Impossible d’envoyer le code par email. Contactez l’administrateur.', 'cp-email-2fa'));
        }
        return true;
    }

    private function verify_code(WP_User $user, $code) {
        if (!preg_match('/^[0-9]{6}$/', (string)$code)) {
            return false;
        }
        $user_id = $user->ID;
        $stored = get_transient('cp_email_2fa_code_' . $user_id);
        if (!$stored) {
            return false;
        }
        return hash_equals((string) $stored, (string) $code);
    }

    private function clear_code(WP_User $user) {
        delete_transient('cp_email_2fa_code_' . $user->ID);
        delete_transient('cp_email_2fa_last_sent_' . $user->ID);
        delete_transient('cp_email_2fa_ctx_' . $user->ID);
    }

    private function mask_email($email) {
        $parts = explode('@', $email);
        if (count($parts) !== 2) return $email;
        $name = $parts[0];
        $domain = $parts[1];
        $maskName = strlen($name) > 2 ? substr($name, 0, 2) . str_repeat('*', max(0, strlen($name) - 2)) : str_repeat('*', strlen($name));
        return $maskName . '@' . $domain;
    }

    public function render_verify_form() {
        $uid = isset($_GET['uid']) ? absint($_GET['uid']) : 0;
        $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
        $redirect_to = isset($_GET['redirect_to']) ? esc_url_raw($_GET['redirect_to']) : admin_url();
        $user = $uid ? get_user_by('id', $uid) : null;
        $masked = $user ? $this->mask_email($user->user_email) : '';

        if (!$user) {
            echo '<p class="message">' . esc_html__('Requête invalide. Revenez à la page de connexion.', 'cp-email-2fa') . '</p>';
            return;
        }

        echo '<p class="message">' . sprintf(esc_html__('Un code a été envoyé à %s. Saisissez-le ci-dessous.', 'cp-email-2fa'), esc_html($masked)) . '</p>';
        echo '<form name="cp-email-2fa" id="loginform" action="' . esc_url(site_url('wp-login.php?action=cp_email_2fa', 'login')) . '" method="post">';
        echo '<p>';
        echo '<label for="cp_2fa_code">' . esc_html__('Code reçu par email', 'cp-email-2fa') . '</label>';
        echo '<input type="text" name="cp_2fa_code" id="cp_2fa_code" class="input" maxlength="6" autocomplete="one-time-code" />';
        echo '</p>';
        echo '<input type="hidden" name="uid" value="' . esc_attr($uid) . '" />';
        echo '<input type="hidden" name="token" value="' . esc_attr($token) . '" />';
        echo '<input type="hidden" name="redirect_to" value="' . esc_attr($redirect_to) . '" />';
        wp_nonce_field('cp_email_2fa_verify_' . $uid);
        echo '<p class="submit"><input type="submit" class="button button-primary" value="' . esc_attr__('Valider le code', 'cp-email-2fa') . '" /></p>';
        echo '</form>';
    }

    public function handle_verify_submission() {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
        if ($action !== 'cp_email_2fa') return;
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        $uid = isset($_POST['uid']) ? absint($_POST['uid']) : 0;
        $token = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';
        $code = isset($_POST['cp_2fa_code']) ? sanitize_text_field($_POST['cp_2fa_code']) : '';
        $redirect_to = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : admin_url();

        if (!$uid || !wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'cp_email_2fa_verify_' . $uid)) {
            wp_safe_redirect(wp_login_url());
            exit;
        }
        $user = get_user_by('id', $uid);
        if (!$user) {
            wp_safe_redirect(wp_login_url());
            exit;
        }
        $ctx = get_transient('cp_email_2fa_ctx_' . $uid);
        if (!$ctx || empty($ctx['token_hash']) || !hash_equals($ctx['token_hash'], wp_hash($token))) {
            wp_safe_redirect(add_query_arg('cp_email_2fa_error', 'token', wp_login_url()));
            exit;
        }
        if (!$this->verify_code($user, $code)) {
            wp_safe_redirect(add_query_arg([
                'action' => 'cp_email_2fa',
                'uid' => $uid,
                'token' => $token,
                'redirect_to' => $redirect_to,
                'error' => 'invalid_code',
            ], wp_login_url()));
            exit;
        }

        // Succès: connecter l'utilisateur et rediriger
        $remember = !empty($ctx['remember']);
        $this->clear_code($user);
        wp_set_current_user($uid);
        wp_set_auth_cookie($uid, $remember);
        do_action('wp_login', $user->user_login, $user);
        wp_safe_redirect($redirect_to);
        exit;
    }

    public function render_user_profile($user) {
        $enabled = (bool) get_user_meta($user->ID, self::META_ENABLED, true);
        echo '<h2>' . esc_html__('Double authentification par email', 'cp-email-2fa') . '</h2>';
        echo '<table class="form-table"><tbody>';
        echo '<tr><th><label for="cp_email_2fa_enabled">' . esc_html__('Activer la double authentification par email', 'cp-email-2fa') . '</label></th><td>';
        echo '<input type="checkbox" name="cp_email_2fa_enabled" id="cp_email_2fa_enabled" value="1" ' . checked($enabled, true, false) . ' />';
        echo '<p class="description">' . esc_html__('Envoi d’un code par email lors de la connexion (en deux étapes).', 'cp-email-2fa') . '</p>';
        echo '</td></tr>';
        wp_nonce_field('cp_email_2fa_update_' . $user->ID, 'cp_email_2fa_nonce');
        echo '<tr><th></th><td>';
        echo '<button type="submit" name="cp_email_2fa_disable" class="button">' . esc_html__('Désactiver', 'cp-email-2fa') . '</button>';
        echo '</td></tr>';
        echo '</tbody></table>';
    }

    public function save_user_profile($user_id) {
        if (!current_user_can('edit_user', $user_id)) return;
        if (!isset($_POST['cp_email_2fa_nonce']) || !wp_verify_nonce($_POST['cp_email_2fa_nonce'], 'cp_email_2fa_update_' . $user_id)) return;
        $enabled = isset($_POST['cp_email_2fa_enabled']) ? 1 : 0;
        update_user_meta($user_id, self::META_ENABLED, $enabled);
        if (isset($_POST['cp_email_2fa_disable'])) {
            delete_transient('cp_email_2fa_code_' . $user_id);
            delete_transient('cp_email_2fa_last_sent_' . $user_id);
            delete_transient('cp_email_2fa_ctx_' . $user_id);
            update_user_meta($user_id, self::META_ENABLED, 0);
        }
    }

    public function maybe_admin_notices() {
        if (!is_user_logged_in()) return;
        $user = wp_get_current_user();
        $enabled = get_user_meta($user->ID, self::META_ENABLED, true);
        if (!$enabled) {
            add_action('admin_notices', function () {
                echo '<div class="notice notice-warning"><p>' . esc_html__('Sécurisez votre compte: activez la double authentification par email dans votre profil.', 'cp-email-2fa') . '</p></div>';
            });
        }
    }
}

new CP_Email_Two_Factor_Auth();