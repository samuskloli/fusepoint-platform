=== CP Email Two-Factor Auth ===
Contributors: Chaque-Pas Compte
Requires at least: 5.8
Tested up to: 6.x
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later

Plugin de double authentification par email (OTP) pour WordPress.

== Description ==
Ce plugin ajoute un second facteur de connexion: un code à usage unique envoyé par email.
- Champ "Code reçu par email" sur la page de connexion.
- Bascule dans le profil utilisateur pour activer/désactiver la 2FA par email.
- Codes de 6 chiffres, valides 10 minutes, anti-spam (délai de renvoi 60s).

== Installation ==
1. Dans l'admin WordPress, allez dans "Extensions > Ajouter > Téléverser".
2. Téléversez l'archive ZIP du plugin (cp-email-2fa.zip) et activez-la.
3. Ouvrez votre profil utilisateur et cochez "Activer la double authentification par email".
4. À la connexion, un code vous est envoyé par email; saisissez-le pour terminer.

== Notes ==
- Assurez-vous que l'envoi d'emails fonctionne (`wp_mail`).
- En cas d'échec d'envoi, contactez l'administrateur (vérifier SMTP, SPF/DKIM).

== Changelog ==
= 1.0.0 =
* Première version: envoi de code OTP par email et validation à la connexion.