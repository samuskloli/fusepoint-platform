const fs = require('fs');
const path = require('path');

const frPath = path.join(__dirname, 'src/lang/fr.js');

try {
  const content = fs.readFileSync(frPath, 'utf8');
  const lines = content.split('\n');
  
  // Chercher la ligne avec dateNotDefined
  const dateNotDefinedIndex = lines.findIndex(line => line.includes('dateNotDefined'));
  
  if (dateNotDefinedIndex !== -1) {
    console.log('📋 Contexte autour de dateNotDefined:');
    const start = Math.max(0, dateNotDefinedIndex - 5);
    const end = Math.min(lines.length, dateNotDefinedIndex + 10);
    
    for (let i = start; i < end; i++) {
      const marker = i === dateNotDefinedIndex ? ' >>> ' : '     ';
      console.log(`${marker}${i + 1}: ${lines[i]}`);
    }
  } else {
    console.log('❌ dateNotDefined non trouvé');
  }
  
  // Vérifier la syntaxe JavaScript de la section projects
  const projectsMatch = content.match(/projects:\s*\{([\s\S]*?)\n\s*\},?\s*\n/);
  
  if (projectsMatch) {
    try {
      const testObj = `{projects: {${projectsMatch[1]}\n}}`;
      eval(`(${testObj})`);
      console.log('\n✅ Syntaxe JavaScript de la section projects valide');
    } catch (syntaxError) {
      console.log('\n❌ Erreur de syntaxe dans la section projects:', syntaxError.message);
      
      // Trouver la ligne problématique
      const projectLines = projectsMatch[1].split('\n');
      console.log('\n🔍 Lignes de la section projects:');
      projectLines.forEach((line, index) => {
        if (line.trim()) {
          console.log(`${index + 1}: ${line}`);
        }
      });
    }
  }
  
} catch (error) {
  console.error('❌ Erreur:', error.message);
}