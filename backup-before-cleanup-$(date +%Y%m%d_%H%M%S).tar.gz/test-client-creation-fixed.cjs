const axios = require('axios');

// Configuration pour tester l'API avec le bon port
const API_BASE_URL = 'http://localhost:3003';

async function testClientCreation() {
    console.log('🧪 Test de création de client avec la configuration corrigée...');
    console.log(`📡 URL de l'API: ${API_BASE_URL}`);
    
    try {
        // Données de test pour un nouveau client
        const clientData = {
            first_name: 'Test',
            last_name: 'Configuration',
            email: 'test.config@example.com',
            phone: '+33123456789',
            company: 'Test Config Company',
            status: 'active'
        };
        
        console.log('📝 Données du client:', JSON.stringify(clientData, null, 2));
        
        // Test de création via l'API
        const response = await axios.post(`${API_BASE_URL}/api/agent/clients`, clientData, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer test-token' // Token de test
            },
            timeout: 10000
        });
        
        console.log('✅ Réponse de l\'API:');
        console.log('📊 Statut:', response.status);
        console.log('📋 Données:', JSON.stringify(response.data, null, 2));
        
        if (response.data && response.data.id) {
            console.log(`🎉 Client créé avec succès! ID: ${response.data.id}`);
            return true;
        } else {
            console.log('⚠️ Réponse inattendue de l\'API');
            return false;
        }
        
    } catch (error) {
        console.error('❌ Erreur lors du test:');
        
        if (error.response) {
            console.error('📊 Statut de l\'erreur:', error.response.status);
            console.error('📋 Données de l\'erreur:', error.response.data);
            console.error('🔗 URL appelée:', error.config?.url);
        } else if (error.request) {
            console.error('📡 Erreur de réseau:', error.message);
            console.error('🔗 URL tentée:', `${API_BASE_URL}/api/agent/clients`);
        } else {
            console.error('⚙️ Erreur de configuration:', error.message);
        }
        
        return false;
    }
}

async function testAPIConnection() {
    console.log('🔌 Test de connexion à l\'API...');
    
    try {
        const response = await axios.get(`${API_BASE_URL}/health`, {
            timeout: 5000
        });
        
        console.log('✅ Connexion API réussie!');
        console.log('📊 Statut:', response.status);
        console.log('📋 Santé:', response.data);
        return true;
        
    } catch (error) {
        console.error('❌ Impossible de se connecter à l\'API:');
        console.error('📡 Erreur complète:', error);
        console.error('📡 Message:', error.message);
        console.error('📡 Code:', error.code);
        console.error('📡 URL tentée:', `${API_BASE_URL}/health`);
        if (error.response) {
            console.error('📊 Statut de réponse:', error.response.status);
            console.error('📋 Données de réponse:', error.response.data);
        }
        return false;
    }
}

async function runTests() {
    console.log('🚀 Démarrage des tests de configuration...');
    console.log('=' .repeat(50));
    
    // Test 1: Connexion API
    const connectionOK = await testAPIConnection();
    console.log('\n' + '-'.repeat(30) + '\n');
    
    if (!connectionOK) {
        console.log('❌ Impossible de continuer sans connexion API');
        return;
    }
    
    // Test 2: Création de client
    const creationOK = await testClientCreation();
    
    console.log('\n' + '='.repeat(50));
    console.log('📊 RÉSULTATS DES TESTS:');
    console.log(`🔌 Connexion API: ${connectionOK ? '✅ OK' : '❌ ÉCHEC'}`);
    console.log(`👤 Création client: ${creationOK ? '✅ OK' : '❌ ÉCHEC'}`);
    
    if (connectionOK && creationOK) {
        console.log('🎉 Tous les tests sont passés! L\'interface devrait maintenant fonctionner.');
    } else {
        console.log('⚠️ Des problèmes persistent. Vérifiez les logs ci-dessus.');
    }
}

// Exécuter les tests
runTests().catch(console.error);