const fs = require('fs');
const path = require('path');

const frPath = path.join(__dirname, 'src/lang/fr.js');
const enPath = path.join(__dirname, 'src/lang/en.js');

function removeDuplicateLines(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    const cleanedLines = [];
    const seenLines = new Set();
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmedLine = line.trim();
      
      // Ignorer les lignes vides et les commentaires pour la déduplication
      if (trimmedLine === '' || trimmedLine.startsWith('//')) {
        cleanedLines.push(line);
        continue;
      }
      
      // Créer une clé unique pour la ligne (sans espaces de début/fin)
      const lineKey = trimmedLine;
      
      if (!seenLines.has(lineKey)) {
        seenLines.add(lineKey);
        cleanedLines.push(line);
      } else {
        console.log(`🗑️  Ligne dupliquée supprimée (ligne ${i + 1}): ${trimmedLine}`);
      }
    }
    
    const cleanedContent = cleanedLines.join('\n');
    fs.writeFileSync(filePath, cleanedContent, 'utf8');
    
    console.log(`✅ Fichier ${path.basename(filePath)} nettoyé: ${lines.length} -> ${cleanedLines.length} lignes`);
    
  } catch (error) {
    console.error(`❌ Erreur lors du nettoyage de ${filePath}:`, error.message);
  }
}

console.log('🧹 Nettoyage des fichiers de traduction...');
removeDuplicateLines(frPath);
removeDuplicateLines(enPath);
console.log('✨ Nettoyage terminé!');