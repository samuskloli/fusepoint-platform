# Système Modulaire de Projets avec Widgets

## Vue d'ensemble

Ce système permet de créer des modèles de projets réutilisables avec des widgets modulaires pour améliorer l'efficacité et la standardisation des projets.

## Architecture

### Base de données

#### Tables principales
- `project_templates` : Modèles de projets
- `widgets` : Widgets disponibles
- `project_template_widgets` : Association modèles-widgets
- `project_widgets` : Widgets des projets créés

#### Migration
```bash
# Exécuter le script de migration
mysql -u username -p database_name < server/database/project_templates_system.sql
```

### Backend (Node.js/Express)

#### Services
- **`projectTemplateService.js`** : Logique métier pour les modèles et widgets
  - Gestion des modèles de projets
  - Gestion des widgets
  - Création de projets à partir de modèles

#### Routes API
- **`/api/project-templates`** : CRUD des modèles de projets
- **`/api/widgets`** : Récupération des widgets disponibles

#### Endpoints principaux
```
GET    /api/project-templates          # Liste des modèles
POST   /api/project-templates          # Créer un modèle
PUT    /api/project-templates/:id      # Modifier un modèle
DELETE /api/project-templates/:id      # Supprimer un modèle
POST   /api/project-templates/:id/duplicate # Dupliquer un modèle

GET    /api/project-templates/:id/widgets    # Widgets d'un modèle
PUT    /api/project-templates/:id/widgets    # Mettre à jour les widgets

POST   /api/project-templates/:id/create-project # Créer projet depuis modèle

GET    /api/widgets                    # Liste des widgets
GET    /api/widgets/categories         # Catégories de widgets
```

### Frontend (Vue.js)

#### Composants principaux

##### Gestion des modèles (Agent)
- **`ProjectTemplatesManagement.vue`** : Interface principale de gestion
- **`TemplateModal.vue`** : Création/édition de modèles
- **`WidgetsModal.vue`** : Gestion des widgets d'un modèle
- **`CreateProjectModal.vue`** : Création de projet depuis modèle

##### Affichage des projets (Client)
- **`ProjectDashboardWidget.vue`** : Tableau de bord projet avec widgets

#### Services frontend
- **`projectTemplateService.js`** : Communication avec l'API
- **`useProjectTemplates.js`** : Composables Vue pour la logique réactive

#### Traductions
- **`src/locales/fr/projectTemplates.json`** : Traductions françaises
- **`src/locales/en/projectTemplates.json`** : Traductions anglaises

## Fonctionnalités

### Pour les Agents

#### Gestion des modèles
- ✅ Créer des modèles de projets
- ✅ Modifier les modèles existants
- ✅ Dupliquer des modèles
- ✅ Activer/désactiver des modèles
- ✅ Supprimer des modèles
- ✅ Filtrer par catégorie
- ✅ Recherche textuelle

#### Gestion des widgets
- ✅ Associer des widgets aux modèles
- ✅ Configurer l'ordre des widgets
- ✅ Activer/désactiver des widgets par modèle
- ✅ Configuration par défaut des widgets

#### Création de projets
- ✅ Créer un projet à partir d'un modèle
- ✅ Personnaliser les détails du projet
- ✅ Héritage automatique des widgets

### Pour les Clients

#### Visualisation des projets
- ✅ Tableau de bord avec widgets dynamiques
- ✅ Progression globale du projet
- ✅ Affichage conditionnel des widgets
- ✅ Mise à jour en temps réel

## Widgets disponibles

### Widgets de base
1. **Checklist** - Liste de tâches à cocher
2. **Calendar** - Calendrier et planification
3. **Files** - Gestion des fichiers
4. **Comments** - Commentaires et discussions
5. **Stats** - Statistiques et métriques
6. **Goals** - Objectifs et KPIs
7. **Team** - Équipe et collaborateurs
8. **History** - Historique des actions
9. **AI** - Assistant IA
10. **TaskList** - Liste de tâches avancée

### Catégories
- **Gestion** : Checklist, TaskList, Goals
- **Communication** : Comments, Team
- **Fichiers** : Files
- **Planification** : Calendar
- **Analyse** : Stats, History
- **IA** : AI

## Configuration

### Variables d'environnement
```env
# Base de données MariaDB
DB_HOST=localhost
DB_USER=your_user
DB_PASSWORD=your_password
DB_NAME=your_database
```

### Permissions
- **Agent/Admin** : Accès complet aux modèles et widgets
- **Client** : Visualisation des projets et widgets associés

## Utilisation

### 1. Créer un modèle de projet
```javascript
// Via l'interface agent
1. Aller dans "Modèles de Projets"
2. Cliquer sur "Créer un Modèle"
3. Remplir les informations (nom, description, durée, etc.)
4. Sauvegarder
```

### 2. Configurer les widgets
```javascript
// Associer des widgets au modèle
1. Cliquer sur "Gérer les Widgets" sur un modèle
2. Sélectionner les widgets souhaités
3. Réorganiser l'ordre si nécessaire
4. Sauvegarder
```

### 3. Créer un projet
```javascript
// Créer un projet depuis un modèle
1. Cliquer sur "Créer un Projet" sur un modèle
2. Sélectionner le client
3. Remplir les détails du projet
4. Créer le projet
```

### 4. Visualiser côté client
```javascript
// Le client voit automatiquement :
- Les informations du projet
- La progression globale
- Les widgets configurés
- Les mises à jour en temps réel
```

## Extensibilité

### Ajouter un nouveau widget

1. **Base de données** : Ajouter l'entrée dans la table `widgets`
```sql
INSERT INTO widgets (nom, description, component_name, categorie, icon, is_active)
VALUES ('MonWidget', 'Description', 'MonWidgetComponent', 'ma_categorie', 'icon-name', 1);
```

2. **Composant Vue** : Créer le composant dans `src/components/widgets/`
```vue
<template>
  <div class="widget-container">
    <!-- Contenu du widget -->
  </div>
</template>

<script>
export default {
  name: 'MonWidgetComponent',
  props: {
    projectId: Number,
    widgetConfig: Object,
    isActive: Boolean
  }
}
</script>
```

3. **Enregistrement** : Ajouter le composant au système de widgets

### Personnaliser un widget existant

1. Modifier le composant Vue correspondant
2. Ajouter des options de configuration si nécessaire
3. Mettre à jour les traductions

## Maintenance

### Logs et monitoring
- Les actions sont loggées via `systemLogsService`
- Surveillance des performances des widgets
- Gestion des erreurs centralisée

### Sauvegarde
- Sauvegarder régulièrement les modèles de projets
- Exporter les configurations de widgets
- Maintenir les traductions à jour

## Dépannage

### Problèmes courants

1. **Widget ne s'affiche pas**
   - Vérifier que le widget est actif
   - Contrôler les permissions
   - Vérifier la configuration du projet

2. **Erreur de création de projet**
   - Vérifier les données du modèle
   - Contrôler les widgets associés
   - Vérifier les permissions client

3. **Performance lente**
   - Optimiser les requêtes de widgets
   - Réduire la fréquence de rafraîchissement
   - Mettre en cache les données statiques

## Roadmap

### Fonctionnalités futures
- [ ] Widgets personnalisables par client
- [ ] Templates de widgets
- [ ] Import/export de modèles
- [ ] Widgets tiers via plugins
- [ ] Analytics des widgets
- [ ] Notifications push pour widgets
- [ ] Widgets collaboratifs en temps réel

## Support

Pour toute question ou problème :
- Documentation technique : Ce fichier
- Code source : `/server/services/projectTemplateService.js`
- Interface : `/src/components/agent/ProjectTemplatesManagement.vue`
- API : `/server/routes/projectTemplates.js`