// Script de test pour la création de client
const axios = require('axios');

// Configuration
const API_URL = 'http://localhost:3003';
const TEST_TOKEN = 'your_test_token_here'; // Remplacer par un vrai token

// Données de test
const testClientData = {
  firstName: 'Test',
  lastName: 'Client',
  email: 'test.client@example.com',
  phone: '+33123456789',
  companyName: 'Test Company',
  isActive: true
};

async function testClientCreation() {
  try {
    console.log('🧪 Test de création de client...');
    console.log('📊 Données:', testClientData);
    
    const response = await axios.post(`${API_URL}/api/agent/clients`, testClientData, {
      headers: {
        'Authorization': `Bearer ${TEST_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Succès!');
    console.log('📋 Réponse:', response.data);
    
  } catch (error) {
    console.log('❌ Erreur:', error.response?.status, error.response?.statusText);
    console.log('📋 Message:', error.response?.data?.message || error.message);
    
    if (error.response?.status === 401) {
      console.log('🔐 Problème d\'authentification - vérifiez le token');
    }
  }
}

// Test de santé de l'API
async function testAPIHealth() {
  try {
    console.log('🏥 Test de santé de l\'API...');
    const response = await axios.get(`${API_URL}/health`);
    console.log('✅ API en ligne:', response.data);
    return true;
  } catch (error) {
    console.log('❌ API hors ligne:', error.message);
    return false;
  }
}

async function runTests() {
  console.log('🚀 Démarrage des tests...');
  
  const apiHealthy = await testAPIHealth();
  if (!apiHealthy) {
    console.log('⚠️ API non disponible - arrêt des tests');
    return;
  }
  
  await testClientCreation();
}

runTests();