/**
 * Script pour créer la table agent_clients manquante dans MariaDB
 */

const MariaDBService = require('./services/mariadbService');
const mariadbService = new MariaDBService();

async function createAgentClientsTable() {
  console.log('🔧 Création de la table agent_clients dans MariaDB...');
  
  try {
    // Initialiser le service MariaDB
    await mariadbService.initialize();
    console.log('✅ Service MariaDB initialisé');
    // SQL adapté pour MariaDB
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS agent_clients (
          id INT AUTO_INCREMENT PRIMARY KEY,
          agent_id INT NOT NULL,
          client_id INT NOT NULL,
          assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          status VARCHAR(50) DEFAULT 'active',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
          UNIQUE KEY unique_agent_client (agent_id, client_id)
      )`;
    
    // Créer la table
    await mariadbService.query(createTableSQL);
    console.log('✅ Table agent_clients créée avec succès');
    
    // Créer les index pour optimiser les performances
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_agent_clients_agent ON agent_clients(agent_id)',
      'CREATE INDEX IF NOT EXISTS idx_agent_clients_client ON agent_clients(client_id)',
      'CREATE INDEX IF NOT EXISTS idx_agent_clients_status ON agent_clients(status)'
    ];
    
    for (const indexSQL of indexes) {
      try {
        await mariadbService.query(indexSQL);
        console.log('✅ Index créé:', indexSQL.split(' ')[5]);
      } catch (error) {
        if (!error.message.includes('Duplicate key name')) {
          console.warn('⚠️ Erreur lors de la création de l\'index:', error.message);
        }
      }
    }
    
    // Insérer des données de test si la table est vide
    const countResult = await mariadbService.query('SELECT COUNT(*) as count FROM agent_clients');
    const count = countResult[0].count;
    
    if (count === 0) {
      console.log('📊 Insertion de données de test...');
      
      // Vérifier d'abord que les utilisateurs existent
      const users = await mariadbService.query('SELECT id, role FROM users WHERE id IN (1, 2, 3)');
      console.log('👥 Utilisateurs trouvés:', users);
      
      if (users.length >= 2) {
        // Trouver un agent et des clients
        const agent = users.find(u => u.role === 'agent');
        const clients = users.filter(u => u.role === 'user' || u.role === 'client');
        
        if (agent && clients.length > 0) {
          for (const client of clients) {
            try {
              await mariadbService.query(
                'INSERT IGNORE INTO agent_clients (agent_id, client_id, status) VALUES (?, ?, ?)',
                [agent.id, client.id, 'active']
              );
              console.log(`✅ Assignation créée: Agent ${agent.id} -> Client ${client.id}`);
            } catch (error) {
              console.warn(`⚠️ Erreur lors de l'assignation Agent ${agent.id} -> Client ${client.id}:`, error.message);
            }
          }
        } else {
          console.log('⚠️ Pas d\'agent ou de client trouvé pour les données de test');
        }
      }
    }
    
    // Vérifier le résultat final
    const finalCount = await mariadbService.query('SELECT COUNT(*) as count FROM agent_clients');
    console.log(`📊 Nombre d'enregistrements dans agent_clients: ${finalCount[0].count}`);
    
    console.log('✅ Script terminé avec succès');
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    console.error('Stack:', error.stack);
    process.exit(1);
  }
}

// Exécuter le script si appelé directement
if (require.main === module) {
  createAgentClientsTable();
}

module.exports = createAgentClientsTable;