const mysql = require('mysql2/promise');
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Configuration de la base de données
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'fusepoint_db',
  password: process.env.DB_PASSWORD || 'FusepointBD2025!',
  database: process.env.DB_NAME || 'fusepoint_db'
};

// Créer une application Express minimale pour tester
const app = express();
app.use(cors());
app.use(express.json());

// Middleware d'authentification simple pour le test
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token === 'test-token') {
    req.user = { id: 1, role: 'admin' };
    next();
  } else {
    res.status(401).json({ error: 'Non autorisé' });
  }
};

// Route de login pour le test
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'admin@fusepoint.com' && password === 'admin123') {
    res.json({ token: 'test-token', user: { id: 1, role: 'admin' } });
  } else {
    res.status(401).json({ error: 'Identifiants invalides' });
  }
});

// Route pour récupérer les agents disponibles
app.get('/api/agent/available', authMiddleware, async (req, res) => {
  let connection;
  try {
    connection = await mysql.createConnection(dbConfig);
    const [agents] = await connection.execute(
      'SELECT id, first_name, last_name, email FROM users WHERE role = "agent" AND is_active = 1'
    );
    res.json(agents);
  } catch (error) {
    console.error('Erreur lors de la récupération des agents:', error);
    res.status(500).json({ error: 'Erreur serveur' });
  } finally {
    if (connection) await connection.end();
  }
});

// Route pour assigner un agent
app.post('/api/agent/assign', authMiddleware, async (req, res) => {
  let connection;
  try {
    const { clientId, agentId } = req.body;
    
    console.log('🎯 Tentative d\'attribution:', { clientId, agentId });
    
    if (!clientId || !agentId) {
      return res.status(400).json({ error: 'clientId et agentId sont requis' });
    }
    
    connection = await mysql.createConnection(dbConfig);
    
    // Vérifier que l'agent existe et est actif
    const [agents] = await connection.execute(
      'SELECT id, first_name, last_name, email FROM users WHERE id = ? AND role = "agent" AND is_active = 1',
      [agentId]
    );
    
    if (agents.length === 0) {
      return res.status(404).json({ error: 'Agent non trouvé ou inactif' });
    }
    
    // Vérifier que le client existe
    const [clients] = await connection.execute(
      'SELECT id, first_name, last_name, email FROM users WHERE id = ?',
      [clientId]
    );
    
    if (clients.length === 0) {
      return res.status(404).json({ error: 'Client non trouvé' });
    }
    
    // Mettre à jour l'agent_id du client
    const [result] = await connection.execute(
      'UPDATE users SET agent_id = ? WHERE id = ?',
      [agentId, clientId]
    );
    
    console.log('✅ Résultat de la mise à jour:', result);
    
    if (result.affectedRows === 0) {
      return res.status(500).json({ error: 'Aucune ligne mise à jour' });
    }
    
    // Vérifier la mise à jour
    const [updatedClient] = await connection.execute(
      'SELECT id, first_name, last_name, email, agent_id FROM users WHERE id = ?',
      [clientId]
    );
    
    res.json({
      success: true,
      message: 'Agent assigné avec succès',
      client: updatedClient[0],
      agent: agents[0]
    });
    
  } catch (error) {
    console.error('❌ Erreur lors de l\'attribution:', error);
    res.status(500).json({ 
      error: 'Erreur serveur',
      details: error.message 
    });
  } finally {
    if (connection) await connection.end();
  }
});

// Route de santé
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

async function testAgentAssignment() {
  let connection;
  let server;
  
  try {
    console.log('🔗 Connexion à la base de données...');
    connection = await mysql.createConnection(dbConfig);
    
    // 1. Vérifier les agents disponibles
    console.log('\n📋 Agents disponibles:');
    const [agents] = await connection.execute(
      'SELECT id, first_name, last_name, email, role FROM users WHERE role = "agent" AND is_active = 1'
    );
    console.log(agents);
    
    // 2. Vérifier les clients disponibles
    console.log('\n👥 Clients disponibles:');
    const [clients] = await connection.execute(
      'SELECT id, first_name, last_name, email, role, agent_id FROM users WHERE role IN ("client", "user") LIMIT 5'
    );
    console.log(clients);
    
    if (agents.length === 0) {
      console.log('❌ Aucun agent trouvé');
      return;
    }
    
    if (clients.length === 0) {
      console.log('❌ Aucun client trouvé');
      return;
    }
    
    // 3. Démarrer le serveur de test
    console.log('\n🚀 Démarrage du serveur de test...');
    const PORT = 3003; // Port différent pour éviter les conflits
    
    server = app.listen(PORT, 'localhost', () => {
      console.log(`✅ Serveur de test démarré sur http://localhost:${PORT}`);
    });
    
    // Attendre que le serveur soit prêt
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 4. Tester la connexion à l'API
    console.log('\n🔐 Test de connexion à l\'API...');
    const loginResponse = await fetch(`http://localhost:${PORT}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: 'admin@fusepoint.com',
        password: 'admin123'
      })
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Erreur de connexion:', loginResponse.status, loginResponse.statusText);
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Connexion réussie');
    
    // 5. Tester l'endpoint des agents disponibles
    console.log('\n📋 Test de l\'endpoint /api/agent/available...');
    const availableAgentsResponse = await fetch(`http://localhost:${PORT}/api/agent/available`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!availableAgentsResponse.ok) {
      console.log('❌ Erreur lors de la récupération des agents:', availableAgentsResponse.status);
      const errorText = await availableAgentsResponse.text();
      console.log('Erreur:', errorText);
      return;
    }
    
    const availableAgentsData = await availableAgentsResponse.json();
    console.log('✅ Agents disponibles via API:', availableAgentsData);
    
    // 6. Tester l'attribution d'agent
    const clientToAssign = clients[0];
    const agentToAssign = agents[0];
    
    console.log(`\n🎯 Test d'attribution: Agent ${agentToAssign.id} (${agentToAssign.email}) -> Client ${clientToAssign.id} (${clientToAssign.email})`);
    
    const assignResponse = await fetch(`http://localhost:${PORT}/api/agent/assign`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        clientId: clientToAssign.id,
        agentId: agentToAssign.id
      })
    });
    
    console.log('📊 Statut de la réponse:', assignResponse.status, assignResponse.statusText);
    
    if (!assignResponse.ok) {
      console.log('❌ Erreur lors de l\'attribution');
      const errorText = await assignResponse.text();
      console.log('Détails de l\'erreur:', errorText);
      
      // Essayer de parser en JSON si possible
      try {
        const errorJson = JSON.parse(errorText);
        console.log('Erreur JSON:', JSON.stringify(errorJson, null, 2));
      } catch (e) {
        console.log('Erreur brute:', errorText);
      }
    } else {
      const assignData = await assignResponse.json();
      console.log('✅ Attribution réussie:', assignData);
      
      // Vérifier dans la base de données
      const [updatedClient] = await connection.execute(
        'SELECT id, first_name, last_name, email, agent_id FROM users WHERE id = ?',
        [clientToAssign.id]
      );
      console.log('📋 Client mis à jour:', updatedClient[0]);
    }
    
  } catch (error) {
    console.error('❌ Erreur:', error);
  } finally {
    if (connection) {
      await connection.end();
    }
    if (server) {
      server.close();
      console.log('🔌 Serveur de test fermé');
    }
  }
}

// Démarrer le test
testAgentAssignment();