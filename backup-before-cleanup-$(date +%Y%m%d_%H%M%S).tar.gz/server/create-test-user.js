require('dotenv').config();
const bcrypt = require('bcrypt');
const MariaDBService = require('./services/mariadbService');

async function createTestUser() {
  const mariadbService = new MariaDBService();
  
  try {
    await mariadbService.initialize();
    console.log('✅ Connexion MariaDB établie');
    
    // Vérifier si l'utilisateur test existe déjà
    const existingUser = await mariadbService.get(
      'SELECT * FROM users WHERE email = ?',
      ['test@fusepoint.com']
    );
    
    if (existingUser) {
      console.log('👤 Utilisateur test existe déjà:', existingUser.email);
      console.log('🔑 Mot de passe: test123456');
      return;
    }
    
    // Créer un nouvel utilisateur test
    const hashedPassword = await bcrypt.hash('test123456', 10);
    
    const result = await mariadbService.run(
      `INSERT INTO users (first_name, last_name, email, password_hash, role, is_active, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, NOW())`,
      ['Test', 'User', 'test@fusepoint.com', hashedPassword, 'user', 1]
    );
    
    console.log('✅ Utilisateur test créé avec succès!');
    console.log('📧 Email: test@fusepoint.com');
    console.log('🔑 Mot de passe: test123456');
    console.log('🆔 ID utilisateur:', result.insertId);
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
  } finally {
    process.exit(0);
  }
}

createTestUser();