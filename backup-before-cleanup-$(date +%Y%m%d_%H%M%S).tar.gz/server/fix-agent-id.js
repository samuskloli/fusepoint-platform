/**
 * Script pour vérifier et ajouter la colonne agent_id à la table users
 */

const mysql = require('mysql2/promise');
const path = require('path');

// Configuration de la base de données MariaDB
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'fusepoint',
  port: process.env.DB_PORT || 3306
};

async function fixAgentIdColumn() {
  console.log('🔧 Vérification et correction de la colonne agent_id...');
  
  try {
    // Ouvrir la connexion à la base de données
    const connection = await mysql.createConnection(dbConfig);
    
    console.log('✅ Connexion à la base de données établie');
    
    // Vérifier la structure actuelle de la table users
    const [tableInfo] = await connection.execute(`
      SELECT COLUMN_NAME as name, DATA_TYPE as type 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'
    `, [dbConfig.database]);
    console.log('📋 Structure actuelle de la table users:');
    tableInfo.forEach(col => {
      console.log(`  - ${col.name}: ${col.type}`);
    });
    
    // Vérifier si la colonne agent_id existe
    const hasAgentId = tableInfo.some(col => col.name === 'agent_id');
    
    if (!hasAgentId) {
      console.log('⚠️ Colonne agent_id manquante, ajout en cours...');
      await connection.execute('ALTER TABLE users ADD COLUMN agent_id INT');
      await connection.execute('CREATE INDEX IF NOT EXISTS idx_users_agent_id ON users(agent_id)');
      console.log('✅ Colonne agent_id ajoutée avec succès');
    } else {
      console.log('✅ Colonne agent_id existe déjà');
    }
    
    // Vérifier la nouvelle structure
    const [newTableInfo] = await connection.execute(`
      SELECT COLUMN_NAME as name, DATA_TYPE as type 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'
    `, [dbConfig.database]);
    console.log('\n📋 Structure finale de la table users:');
    newTableInfo.forEach(col => {
      console.log(`  - ${col.name}: ${col.type}`);
    });
    
    await connection.end();
    console.log('\n🎉 Vérification terminée avec succès!');
  
    
  } catch (error) {
    console.error('❌ Erreur lors de la vérification:', error);
  }
}

// Exécuter la vérification
fixAgentIdColumn();