const fetch = require('node-fetch');
const mysql = require('mysql2/promise');

// Configuration de la base de données
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'fusepoint_db',
  password: process.env.DB_PASSWORD || 'FusepointBD2025!',
  database: process.env.DB_NAME || 'fusepoint_db'
};

const API_BASE_URL = 'http://localhost:3002';

async function testAgentAssignment() {
  let connection;
  
  try {
    console.log('🔗 Connexion à la base de données...');
    connection = await mysql.createConnection(dbConfig);
    
    // 1. Vérifier les agents disponibles
    console.log('\n📋 Agents disponibles:');
    const [agents] = await connection.execute(
      'SELECT id, first_name, last_name, email, role FROM users WHERE role = "agent" AND is_active = 1'
    );
    console.log(agents);
    
    // 2. Vérifier les clients disponibles
    console.log('\n👥 Clients disponibles:');
    const [clients] = await connection.execute(
      'SELECT id, first_name, last_name, email, role, agent_id FROM users WHERE role IN ("client", "user") LIMIT 5'
    );
    console.log(clients);
    
    if (agents.length === 0) {
      console.log('❌ Aucun agent trouvé');
      return;
    }
    
    if (clients.length === 0) {
      console.log('❌ Aucun client trouvé');
      return;
    }
    
    // 3. Tester la connexion à l'API
    console.log('\n🔐 Test de connexion à l\'API...');
    const loginResponse = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: 'admin@fusepoint.com',
        password: 'admin123'
      })
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Erreur de connexion:', loginResponse.status, loginResponse.statusText);
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Connexion réussie');
    
    // 4. Tester l'endpoint des agents disponibles
    console.log('\n📋 Test de l\'endpoint /api/agent/available...');
    const availableAgentsResponse = await fetch(`${API_BASE_URL}/api/agent/available`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!availableAgentsResponse.ok) {
      console.log('❌ Erreur lors de la récupération des agents:', availableAgentsResponse.status);
      const errorText = await availableAgentsResponse.text();
      console.log('Erreur:', errorText);
      return;
    }
    
    const availableAgentsData = await availableAgentsResponse.json();
    console.log('✅ Agents disponibles via API:', availableAgentsData);
    
    // 5. Tester l'attribution d'agent
    const clientToAssign = clients[0];
    const agentToAssign = agents[0];
    
    console.log(`\n🎯 Test d'attribution: Agent ${agentToAssign.id} (${agentToAssign.email}) -> Client ${clientToAssign.id} (${clientToAssign.email})`);
    
    const assignResponse = await fetch(`${API_BASE_URL}/api/agent/assign`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        clientId: clientToAssign.id,
        agentId: agentToAssign.id
      })
    });
    
    console.log('📊 Statut de la réponse:', assignResponse.status, assignResponse.statusText);
    
    if (!assignResponse.ok) {
      console.log('❌ Erreur lors de l\'attribution');
      const errorText = await assignResponse.text();
      console.log('Détails de l\'erreur:', errorText);
      
      // Essayer de parser en JSON si possible
      try {
        const errorJson = JSON.parse(errorText);
        console.log('Erreur JSON:', JSON.stringify(errorJson, null, 2));
      } catch (e) {
        console.log('Erreur brute:', errorText);
      }
    } else {
      const assignData = await assignResponse.json();
      console.log('✅ Attribution réussie:', assignData);
      
      // Vérifier dans la base de données
      const [updatedClient] = await connection.execute(
        'SELECT id, first_name, last_name, email, agent_id FROM users WHERE id = ?',
        [clientToAssign.id]
      );
      console.log('📋 Client mis à jour:', updatedClient[0]);
    }
    
  } catch (error) {
    console.error('❌ Erreur:', error);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

testAgentAssignment();