const MariaDBService = require('./services/mariadbService');

async function testClientProjects() {
  const mariadbService = new MariaDBService();
  try {
    console.log('🔍 Test des projets clients...');
    
    // Initialiser la base de données
    await mariadbService.initialize();
    
    // 1. Vérifier s'il y a des projets dans la base
    console.log('\n1. Vérification des projets existants:');
    const allProjects = await mariadbService.query('SELECT * FROM projects LIMIT 10');
    console.log(`Nombre total de projets: ${allProjects.length}`);
    if (allProjects.length > 0) {
      console.log('Projets:', allProjects.map(p => ({ id: p.id, name: p.name, client_id: p.client_id, status: p.status })));
    }
    
    // 2. Vérifier les clients
    console.log('\n2. Vérification des clients:');
    const clients = await mariadbService.query('SELECT * FROM users WHERE role IN ("user", "client") LIMIT 5');
    console.log(`Nombre de clients: ${clients.length}`);
    if (clients.length > 0) {
      console.log('Clients:', clients.map(c => ({ id: c.id, email: c.email, first_name: c.first_name, agent_id: c.agent_id })));
    }
    
    // 3. Vérifier les assignations agent-client
    console.log('\n3. Vérification des assignations agent-client:');
    const agentClients = await mariadbService.query('SELECT * FROM agent_clients LIMIT 10');
    console.log(`Nombre d'assignations: ${agentClients.length}`);
    if (agentClients.length > 0) {
      console.log('Assignations:', agentClients);
    }
    
    // 4. Tester la récupération des projets pour le client 17 (qui a des projets)
    console.log('\n4. Test des projets pour le client 17:');
    const client17Projects = await mariadbService.query('SELECT * FROM projects WHERE client_id = 17');
    console.log(`Projets du client 17: ${client17Projects.length}`);
    if (client17Projects.length > 0) {
      console.log('Détails:', client17Projects.map(p => ({ id: p.id, name: p.name, status: p.status })));
      
      // Calculer les statistiques
      const totalProjects = client17Projects.length;
      const completedProjects = client17Projects.filter(p => p.status === 'completed' || p.status === 'terminé').length;
      const activeProjects = client17Projects.filter(p => p.status === 'en_cours' || p.status === 'in_progress').length;
      
      console.log('Statistiques calculées:');
      console.log(`- Total: ${totalProjects}`);
      console.log(`- En cours: ${activeProjects}`);
      console.log(`- Terminés: ${completedProjects}`);
    }
    
    // 5. Vérifier si l'agent 1 a accès au client 17
    console.log('\n5. Vérification de l\'accès agent-client:');
    const agentAccess = await mariadbService.query(
      'SELECT * FROM agent_clients WHERE agent_id = 1 AND client_id = 17'
    );
    console.log(`Accès agent 1 -> client 17: ${agentAccess.length > 0 ? 'OUI' : 'NON'}`);
    
    // Si pas d'accès, créer l'assignation
    if (agentAccess.length === 0) {
      console.log('Création de l\'assignation agent-client...');
      await mariadbService.query(
        'INSERT INTO agent_clients (agent_id, client_id, assigned_at) VALUES (1, 17, NOW())'
      );
      console.log('✅ Assignation créée');
    }
    
    // 6. Tester l'endpoint API directement
    console.log('\n6. Test de l\'endpoint API:');
    console.log('Pour tester l\'API, utilisez:');
    console.log('curl -H "Authorization: Bearer <token>" http://localhost:3000/api/agent/clients/17/projects');
    
    console.log('\n✅ Test terminé avec succès!');
    
  } catch (error) {
    console.error('❌ Erreur lors du test:', error);
  } finally {
    if (mariadbService && typeof mariadbService.close === 'function') {
      await mariadbService.close();
    }
    process.exit(0);
  }
}

testClientProjects();