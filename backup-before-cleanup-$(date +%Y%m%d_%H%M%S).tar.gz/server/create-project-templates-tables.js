const fs = require('fs');
const path = require('path');
const MariaDBService = require('./services/mariadbService');

async function createProjectTemplatesTables() {
  const mariadbService = new MariaDBService();
  
  try {
    console.log('🔧 Création des tables du système de templates de projets...');
    
    // Lire le fichier SQL
    const sqlPath = path.join(__dirname, 'database', 'project_templates_system.sql');
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');
    
    // Diviser le contenu en requêtes individuelles
    const queries = sqlContent
      .split(';')
      .map(query => query.trim())
      .filter(query => query.length > 0 && !query.startsWith('--'));
    
    console.log(`📝 Exécution de ${queries.length} requêtes...`);
    
    for (let i = 0; i < queries.length; i++) {
      const query = queries[i];
      if (query.trim()) {
        try {
          console.log(`⏳ Exécution de la requête ${i + 1}/${queries.length}...`);
          await mariadbService.query(query);
          console.log(`✅ Requête ${i + 1} exécutée avec succès`);
        } catch (error) {
          if (error.message.includes('already exists') || error.message.includes('Duplicate')) {
            console.log(`⚠️ Requête ${i + 1} ignorée (élément déjà existant)`);
          } else {
            console.error(`❌ Erreur lors de l'exécution de la requête ${i + 1}:`, error.message);
            console.log('Requête:', query.substring(0, 100) + '...');
          }
        }
      }
    }
    
    console.log('✅ Tables du système de templates créées avec succès!');
    
    // Vérifier que les tables ont été créées
    const tables = await mariadbService.query("SHOW TABLES LIKE '%template%'");
    console.log('📋 Tables créées:', tables.map(t => Object.values(t)[0]));
    
  } catch (error) {
    console.error('❌ Erreur lors de la création des tables:', error);
  } finally {
    process.exit(0);
  }
}

createProjectTemplatesTables();