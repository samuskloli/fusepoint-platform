#!/bin/bash
# Script de test des schémas de base de données
echo "Test des schémas de base de données"