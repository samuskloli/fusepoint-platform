/**
 * Script pour créer la table agent_clients manquante
 */

const mysql = require('mysql2/promise');
const path = require('path');
const fs = require('fs');

// Configuration de la base de données MariaDB
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'fusepoint',
  port: process.env.DB_PORT || 3306
};

async function createAgentClientsTable() {
  console.log('🔧 Création de la table agent_clients...');
  
  try {
    // Ouvrir la connexion à la base de données
    const connection = await mysql.createConnection(dbConfig);
    
    console.log('✅ Connexion à la base de données établie');
    
    // Lire le fichier SQL
    const sqlContent = fs.readFileSync(path.join(__dirname, 'database/agent_clients_schema.sql'), 'utf8');
    
    // Exécuter le SQL (diviser en requêtes individuelles)
    const queries = sqlContent.split(';').filter(query => query.trim());
    for (const query of queries) {
      if (query.trim()) {
        await connection.execute(query);
      }
    }
    
    console.log('✅ Table agent_clients créée avec succès');
    
    // Vérifier que la table existe
    const [tableInfo] = await connection.execute(`
      SELECT COLUMN_NAME as name, DATA_TYPE as type 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'agent_clients'
    `, [dbConfig.database]);
    console.log('📋 Structure de la table agent_clients:');
    tableInfo.forEach(col => {
      console.log(`  - ${col.name}: ${col.type}`);
    });
    
    // Vérifier les données
    const [countResult] = await connection.execute('SELECT COUNT(*) as count FROM agent_clients');
    console.log(`📊 Nombre d'enregistrements: ${countResult[0].count}`);
    
    await connection.end();
    console.log('✅ Script terminé avec succès');
  
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  }
}

createAgentClientsTable();