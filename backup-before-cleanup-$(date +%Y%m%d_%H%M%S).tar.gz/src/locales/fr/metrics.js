/**
 * Traductions françaises pour les métriques
 */

export default {
  potentialValue: 'Valeur Potentielle',
  source: 'Source'
};