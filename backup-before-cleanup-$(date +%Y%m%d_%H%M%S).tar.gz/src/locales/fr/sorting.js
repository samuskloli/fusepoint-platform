/**
 * Traductions françaises pour le tri
 */

export default {
  aiScore: 'Score IA',
  lastActivity: 'Dernière activité',
  lifetimeValue: 'Valeur vie',
  churnRisk: 'Risque churn',
  name: 'Nom'
};