/**
 * Traductions françaises pour la marque
 */

export default {
  fusepointHub: 'Fusepoint Hub'
};