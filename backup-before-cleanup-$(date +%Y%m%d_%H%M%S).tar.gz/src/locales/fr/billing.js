/**
 * Traductions françaises pour la facturation
 */

export default {
  currentPlan: 'Plan Actuel',
  usage: 'Utilisation',
  billing: 'Facturation',
  paymentHistory: 'Historique des Paiements'
};