/**
 * Traductions françaises pour le marketing
 */

export default {
  activeCampaigns: 'Campagnes Actives',
  emailsSent: 'Emails Envoyés',
  openRate: 'Taux d\'Ouverture',
  clickRate: 'Taux de Clic',
  unsubscribes: 'Désabonnements'
};