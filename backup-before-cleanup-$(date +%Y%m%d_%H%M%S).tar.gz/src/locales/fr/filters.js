/**
 * Traductions françaises pour les filtres
 */

export default {
  allSegments: 'Tous les segments'
};