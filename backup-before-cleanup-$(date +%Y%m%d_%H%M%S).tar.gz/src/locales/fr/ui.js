export default {
  "close-sidebar": "Fermer la barre latérale",
  "toggle-sidebar": "Basculer la barre latérale",
  "open-chat": "Ouvrir le chat",
  "menu-open": "Menu ouvert",
  "menu-close": "Menu fermé",
  "all-disconnected": "Tous déconnectés",
  "logout-confirmed": "Déconnexion confirmée",
  "project-updated": "Projet mis à jour"
};
