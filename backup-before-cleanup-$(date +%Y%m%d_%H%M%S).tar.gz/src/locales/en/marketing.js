/**
 * English translations for marketing
 */

export default {
  activeCampaigns: 'Active Campaigns',
  emailsSent: 'Emails Sent',
  openRate: 'Open Rate',
  clickRate: 'Click Rate',
  unsubscribes: 'Unsubscribes'
};