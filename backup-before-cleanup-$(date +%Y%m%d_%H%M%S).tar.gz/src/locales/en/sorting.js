/**
 * English translations for sorting
 */

export default {
  aiScore: 'AI Score',
  lastActivity: 'Last Activity',
  lifetimeValue: 'Lifetime Value',
  churnRisk: 'Churn Risk',
  name: 'Name'
};