export default {
  "close-sidebar": "Close sidebar",
  "toggle-sidebar": "Toggle sidebar",
  "open-chat": "Open chat",
  "menu-open": "Menu open",
  "menu-close": "Menu close",
  "all-disconnected": "All disconnected",
  "logout-confirmed": "Logout confirmed",
  "project-updated": "Project updated"
};
