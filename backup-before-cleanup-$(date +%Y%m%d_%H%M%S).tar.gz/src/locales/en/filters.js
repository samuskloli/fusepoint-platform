/**
 * English translations for filters
 */

export default {
  allSegments: 'All segments'
};