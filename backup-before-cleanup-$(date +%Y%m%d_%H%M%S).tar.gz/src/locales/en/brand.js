/**
 * English translations for brand
 */

export default {
  fusepointHub: 'Fusepoint Hub'
};