/**
 * English translations for metrics
 */

export default {
  potentialValue: 'Potential Value',
  source: 'Source'
};