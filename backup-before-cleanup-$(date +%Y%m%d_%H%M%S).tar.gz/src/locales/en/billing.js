/**
 * English translations for billing
 */

export default {
  currentPlan: 'Current Plan',
  usage: 'Usage',
  billing: 'Billing',
  paymentHistory: 'Payment History'
};