<template>
  <SidebarNavSection title="Navigation" :isCollapsed="isCollapsed">
    <!-- Tableau de bord -->
    <SidebarNavItem
      to="/dashboard"
      label="Tableau de bord"
      iconPath="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
      :isCollapsed="isCollapsed"
      exactMatch
    />

    <!-- Analytics -->
    <SidebarNavItem
      to="/analytics"
      label="Analytics"
      iconPath="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
      :isCollapsed="isCollapsed"
    />

    <!-- Services -->
    <SidebarNavItem
      to="/services"
      label="Services"
      iconPath="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
      :isCollapsed="isCollapsed"
    />

    <!-- Projets -->
    <SidebarNavItem
      to="/projects"
      label="Projets"
      iconPath="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
      :isCollapsed="isCollapsed"
    />

    <!-- Marketing -->
    <SidebarNavItem
      to="/marketing"
      label="Marketing"
      iconPath="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"
      :isCollapsed="isCollapsed"
    />



    <!-- Rapports -->
    <SidebarNavItem
      to="/reports"
      label="Rapports"
      iconPath="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
      :isCollapsed="isCollapsed"
    />
  </SidebarNavSection>
</template>

<script>
import SidebarNavSection from './SidebarNavSection.vue'
import SidebarNavItem from './SidebarNavItem.vue'

export default {
  name: 'SidebarMainNav',
  components: {
    SidebarNavSection,
    SidebarNavItem
  },
  props: {
    isCollapsed: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style scoped>
/* Utilise les classes centralisées */
</style>