import axios from 'axios';

// Configuration
const BASE_URL = 'http://localhost:3003';
const TEST_PROJECT_ID = 1; // Remplacez par un ID de projet existant
const TEST_TOKEN = 'your_jwt_token_here'; // Remplacez par un token valide

// Données de test pour la mise à jour
const updateData = {
  name: 'Projet Test Modifié',
  description: 'Description mise à jour via test',
  deadline: '2025-12-31',
  budget: 5000,
  priority: 'high',
  status: 'active'
};

async function testProjectUpdate() {
  try {
    console.log('🧪 Test de mise à jour de projet...');
    console.log('📊 Données envoyées:', JSON.stringify(updateData, null, 2));
    
    const response = await axios.put(
      `${BASE_URL}/api/agent/projects/${TEST_PROJECT_ID}`,
      updateData,
      {
        headers: {
          'Authorization': `Bearer ${TEST_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('✅ Succès! Réponse:', JSON.stringify(response.data, null, 2));
    
  } catch (error) {
    console.error('❌ Erreur lors du test:');
    console.error('Status:', error.response?.status);
    console.error('Message:', error.response?.data?.message || error.message);
    console.error('Données complètes:', JSON.stringify(error.response?.data, null, 2));
  }
}

// Fonction pour tester la récupération d'un projet
async function testGetProject() {
  try {
    console.log('🔍 Test de récupération de projet...');
    
    const response = await axios.get(
      `${BASE_URL}/api/agent/projects/${TEST_PROJECT_ID}`,
      {
        headers: {
          'Authorization': `Bearer ${TEST_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('✅ Projet récupéré:', JSON.stringify(response.data, null, 2));
    
  } catch (error) {
    console.error('❌ Erreur lors de la récupération:');
    console.error('Status:', error.response?.status);
    console.error('Message:', error.response?.data?.message || error.message);
  }
}

// Instructions d'utilisation
console.log('📝 Instructions:');
console.log('1. Remplacez TEST_TOKEN par un token JWT valide');
console.log('2. Remplacez TEST_PROJECT_ID par un ID de projet existant');
console.log('3. Exécutez: node test_project_update.js');
console.log('');

// Décommentez les lignes suivantes pour exécuter les tests
// testGetProject();
// testProjectUpdate();

export { testProjectUpdate, testGetProject };