const axios = require('axios');

// Configuration
const API_BASE = 'http://localhost:3000';
const testClient = {
  firstName: 'Test',
  lastName: 'Client',
  email: 'test.client@example.com',
  phone: '+33123456789',
  companyName: 'Test Company',
  isActive: true
};

async function testClientCreation() {
  console.log('🧪 Test de création de client via API');
  console.log('=' .repeat(50));
  
  try {
    // Test 1: Vérifier la connexion au serveur
    console.log('\n1. Test de connexion au serveur...');
    const healthResponse = await axios.get(`${API_BASE}/health`);
    console.log('✅ Serveur accessible:', healthResponse.status);
    
    // Test 2: Tenter de créer un client
    console.log('\n2. Test de création de client...');
    console.log('Données envoyées:', JSON.stringify(testClient, null, 2));
    
    const createResponse = await axios.post(`${API_BASE}/api/agent/clients`, testClient, {
      headers: {
        'Content-Type': 'application/json'
        // Note: En production, il faudrait ajouter l'authentification
        // 'Authorization': 'Bearer ' + token
      }
    });
    
    console.log('✅ Client créé avec succès!');
    console.log('Réponse:', JSON.stringify(createResponse.data, null, 2));
    
    // Test 3: Vérifier que le client apparaît dans la liste
    console.log('\n3. Vérification de la liste des clients...');
    const listResponse = await axios.get(`${API_BASE}/api/agent/clients`);
    console.log(`✅ ${listResponse.data.data?.length || 0} clients trouvés`);
    
    if (listResponse.data.data?.length > 0) {
      const lastClient = listResponse.data.data[0];
      console.log('Dernier client:', {
        id: lastClient.id,
        nom: `${lastClient.first_name} ${lastClient.last_name}`,
        email: lastClient.email
      });
    }
    
  } catch (error) {
    console.error('❌ Erreur lors du test:');
    
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', JSON.stringify(error.response.data, null, 2));
      console.error('Headers:', error.response.headers);
    } else if (error.request) {
      console.error('Pas de réponse du serveur:', error.message);
    } else {
      console.error('Erreur de configuration:', error.message);
    }
  }
}

// Exécuter le test
testClientCreation();