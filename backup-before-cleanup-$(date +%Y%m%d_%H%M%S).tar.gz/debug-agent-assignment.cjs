const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function debugAgentAssignment() {
  console.log('🔍 Debug de l\'assignation d\'agent...');
  
  try {
    // Étape 1: Vérifier que le serveur répond
    console.log('\n1️⃣ Test de connectivité du serveur...');
    try {
      const { stdout: healthResponse } = await execPromise('curl -s http://localhost:3002/health');
      console.log('✅ Serveur accessible:', healthResponse);
    } catch (error) {
      console.log('❌ Serveur non accessible:', error.message);
      return;
    }
    
    // Étape 2: Test de connexion
    console.log('\n2️⃣ Test de connexion...');
    const loginCommand = `curl -s -X POST http://localhost:3002/api/auth/login \
      -H "Content-Type: application/json" \
      -d '{"email":"admin@fusepoint.com","password":"admin123"}'`;
    
    const { stdout: loginResponse } = await execPromise(loginCommand);
    console.log('Réponse de connexion:', loginResponse);
    
    const loginData = JSON.parse(loginResponse);
    
    if (!loginData.success) {
      console.log('❌ Échec de la connexion:', loginData.message);
      return;
    }
    
    const accessToken = loginData.tokens?.accessToken || loginData.accessToken;
    if (!accessToken) {
      console.log('❌ Token d\'accès non reçu');
      return;
    }
    
    console.log('✅ Connexion réussie, token reçu');
    
    // Étape 3: Vérifier les agents disponibles
    console.log('\n3️⃣ Récupération des agents...');
    const agentsCommand = `curl -s -X GET http://localhost:3002/api/agent/available \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json"`;
    
    const { stdout: agentsResponse } = await execPromise(agentsCommand);
    console.log('Réponse agents:', agentsResponse);
    
    const agentsData = JSON.parse(agentsResponse);
    
    if (!agentsData.success || !agentsData.data || agentsData.data.length === 0) {
      console.log('❌ Aucun agent trouvé');
      return;
    }
    
    console.log(`✅ ${agentsData.data.length} agent(s) trouvé(s):`);
    agentsData.data.forEach(agent => {
      console.log(`   - ID: ${agent.id}, Nom: ${agent.first_name} ${agent.last_name}, Email: ${agent.email}`);
    });
    
    // Étape 4: Vérifier les clients
    console.log('\n4️⃣ Récupération des clients...');
    const clientsCommand = `curl -s -X GET http://localhost:3002/api/agent/clients \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json"`;
    
    const { stdout: clientsResponse } = await execPromise(clientsCommand);
    console.log('Réponse clients:', clientsResponse);
    
    const clientsData = JSON.parse(clientsResponse);
    
    if (!clientsData.success || !clientsData.data || clientsData.data.length === 0) {
      console.log('❌ Aucun client trouvé');
      return;
    }
    
    console.log(`✅ ${clientsData.data.length} client(s) trouvé(s):`);
    clientsData.data.slice(0, 3).forEach(client => {
      console.log(`   - ID: ${client.id}, Nom: ${client.first_name} ${client.last_name}, Email: ${client.email}, Agent actuel: ${client.agent_id || 'Aucun'}`);
    });
    
    // Étape 5: Test d'assignation
    // Utiliser l'agent ID 36 qui existe dans la base de données
    const agentId = 36;
    // Utiliser le client ID 35 qui n'a pas encore d'agent assigné
    const clientId = 35;
    
    console.log(`\n5️⃣ Test d'assignation de l'agent ${agentId} au client ${clientId}...`);
    const assignCommand = `curl -s -X POST http://localhost:3002/api/client/${clientId}/assign-agent \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json" \
      -d '{"agentId":${agentId}}'`;
    
    console.log('Commande d\'assignation:', assignCommand);
    
    const { stdout: assignResponse } = await execPromise(assignCommand);
    console.log('Réponse d\'assignation:', assignResponse);
    
    const assignData = JSON.parse(assignResponse);
    
    if (assignData.success) {
      console.log('✅ Assignation réussie!');
      console.log('   Données:', JSON.stringify(assignData.data, null, 2));
    } else {
      console.log('❌ Échec de l\'assignation:', assignData.message || 'Erreur inconnue');
      console.log('   Erreur complète:', JSON.stringify(assignData, null, 2));
    }
    
  } catch (error) {
    console.error('❌ Erreur lors du debug:', error.message);
    console.error('Stack trace:', error.stack);
  }
}

debugAgentAssignment();