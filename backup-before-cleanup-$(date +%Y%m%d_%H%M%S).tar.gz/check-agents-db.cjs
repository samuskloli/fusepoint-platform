const databaseService = require('./server/services/databaseService');

async function checkAgents() {
  console.log('🔍 Vérification des agents dans la base de données...');
  
  try {
    // Initialiser la base de données
    await databaseService.initialize();
    
    // Récupérer tous les agents
    const agents = await databaseService.query(
      'SELECT id, first_name, last_name, email, role, is_active FROM users WHERE role IN ("agent", "admin", "super_admin")'
    );
    
    console.log(`\n✅ ${agents.length} agent(s) trouvé(s) dans la base de données:`);
    agents.forEach(agent => {
      console.log(`   - ID: ${agent.id}, Nom: ${agent.first_name} ${agent.last_name}, Email: ${agent.email}, Rôle: ${agent.role}, Actif: ${agent.is_active}`);
    });
    
    // Récupérer quelques clients
    const clients = await databaseService.query(
      'SELECT id, first_name, last_name, email, agent_id FROM users WHERE role IN ("user", "client") LIMIT 5'
    );
    
    console.log(`\n✅ ${clients.length} client(s) trouvé(s) dans la base de données:`);
    clients.forEach(client => {
      console.log(`   - ID: ${client.id}, Nom: ${client.first_name} ${client.last_name}, Email: ${client.email}, Agent ID: ${client.agent_id || 'Aucun'}`);
    });
    
    // Test d'assignation directe
    if (agents.length > 0 && clients.length > 0) {
      const agentId = agents[0].id;
      const clientId = clients[0].id;
      
      console.log(`\n🎯 Test d'assignation directe: Agent ${agentId} -> Client ${clientId}`);
      
      await databaseService.run(
        'UPDATE users SET agent_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [agentId, clientId]
      );
      
      // Vérifier l'assignation
      const updatedClient = await databaseService.get(
        'SELECT id, first_name, last_name, agent_id FROM users WHERE id = ?',
        [clientId]
      );
      
      console.log('✅ Assignation directe réussie!');
      console.log(`   Client: ${updatedClient.first_name} ${updatedClient.last_name}`);
      console.log(`   Agent ID assigné: ${updatedClient.agent_id}`);
    }
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    console.error('Stack trace:', error.stack);
  } finally {
    process.exit(0);
  }
}

checkAgents();