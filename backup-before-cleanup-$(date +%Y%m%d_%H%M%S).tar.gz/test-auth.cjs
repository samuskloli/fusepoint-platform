const axios = require('axios');

// Configuration
const BASE_URL = 'http://localhost:3003/api';
const TEST_USER = {
  email: 'admin@fusepoint.com',
  password: 'admin123'
};

async function testAuthentication() {
  console.log('🔍 Test d\'authentification...');
  
  try {
    // 1. Test de connexion
    console.log('\n1. Test de connexion...');
    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, TEST_USER);
    console.log('✅ Connexion réussie');
    console.log('Token reçu:', loginResponse.data.tokens?.accessToken ? 'Oui' : 'Non');
    
    const accessToken = loginResponse.data.tokens?.accessToken;
    if (!accessToken) {
      console.log('❌ Aucun token d\'accès reçu');
      return;
    }
    
    // 2. Test de validation du token
    console.log('\n2. Test de validation du token...');
    const meResponse = await axios.get(`${BASE_URL}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
    console.log('✅ Token valide');
    console.log('Utilisateur:', meResponse.data.user?.email);
    console.log('Rôle:', meResponse.data.user?.role);
    
    // 3. Test de création de client
    console.log('\n3. Test de création de client...');
    const clientData = {
    first_name: 'Test',
    last_name: 'Client',
    email: 'test@example.com',
    phone: '+33123456789',
    company: 'Test Company',
    status: 'active'
  };
    
    const createClientResponse = await axios.post(`${BASE_URL}/agent/clients`, clientData, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
    console.log('✅ Client créé avec succès');
    console.log('ID du client:', createClientResponse.data.client?.id);
    
  } catch (error) {
    console.error('❌ Erreur complète:', error);
    console.error('❌ Erreur:', error.response?.status, error.response?.statusText);
    console.error('Message:', error.response?.data?.error || error.message);
    console.error('Code:', error.code);
    
    if (error.response?.status === 401) {
      console.log('\n🔍 Détails de l\'erreur 401:');
      console.log('Headers de la requête:', error.config?.headers);
      console.log('URL:', error.config?.url);
    }
  }
}

// Exécuter le test
testAuthentication();