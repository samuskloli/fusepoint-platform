# Système de Traduction Unifié - Fusepoint Platform

## Vue d'ensemble

Le système de traduction a été unifié pour utiliser exclusivement le composable `useTranslation()`. Les propriétés globales `$t()`, `$tSection()`, etc. ont été supprimées pour éviter les conflits et améliorer la maintenabilité.

## Architecture Unifiée

### Composants du Système

1. **Service de traduction** (`src/services/translationService.js`)
   - Gère les traductions côté client
   - Charge les fichiers de langue
   - Fournit les méthodes de base

2. **Store Pinia** (`src/stores/translation.js`)
   - État réactif des traductions
   - Gestion de la langue courante
   - Interface avec le service

3. **Composable Vue** (`src/composables/useTranslation.js`)
   - Interface principale pour les composants
   - Expose les fonctions de traduction
   - Gestion réactive de l'état

4. **Plugin Vue** (`src/plugins/translation.js`)
   - Directives personnalisées (`v-t`, `v-t-placeholder`, `v-t-title`)
   - Fonctions de formatage globales
   - Plus de propriétés globales $t()

5. **Fichiers de traduction** (`src/lang/`)
   - `fr.js` - Traductions françaises
   - `en.js` - Traductions anglaises

## Utilisation

### Dans les Composants Vue

```vue
<template>
  <div>
    <h1>{{ t('dashboard.title') }}</h1>
    <p>{{ t('dashboard.welcome', { name: userName }) }}</p>
    
    <!-- Utilisation des directives -->
    <input v-t-placeholder="'placeholders.search'" />
    <button v-t-title="'tooltips.save'">{{ t('common.save') }}</button>
  </div>
</template>

<script>
import { useTranslation } from '../composables/useTranslation'

export default {
  setup() {
    const { t, setLanguage, currentLanguage } = useTranslation()
    
    return {
      t,
      setLanguage,
      currentLanguage
    }
  }
}
</script>
```

### Fonctions Disponibles

```javascript
const {
  t,                    // Fonction de traduction principale
  tSection,            // Récupère une section complète
  exists,              // Vérifie l'existence d'une clé
  setLanguage,         // Change la langue
  currentLanguage,     // Langue courante (réactif)
  availableLanguages,  // Langues disponibles
  isLoading,          // État de chargement
  error               // Erreurs éventuelles
} = useTranslation()
```

### Directives Disponibles

```vue
<!-- Traduction du contenu textuel -->
<span v-t="'common.loading'"></span>

<!-- Traduction avec paramètres -->
<span v-t="{ key: 'welcome.message', params: { name: 'John' } }"></span>

<!-- Traduction du placeholder -->
<input v-t-placeholder="'placeholders.email'" />

<!-- Traduction du titre/tooltip -->
<button v-t-title="'tooltips.delete'">🗑️</button>
```

## Migration Effectuée

### Changements Automatiques

✅ **181 remplacements** de `$t()` vers `t()`
✅ **17 fichiers modifiés** automatiquement
✅ **9 imports** `useTranslation` ajoutés
✅ **Propriétés globales supprimées** du plugin

### Fichiers Migrés

- `src/views/ClientProjectDashboard.vue`
- `src/views/AgentProjects.vue`
- `src/views/ResetPassword.vue`
- `src/views/ForgotPassword.vue`
- `src/views/Register.vue`
- `src/components/agent/ProjectTemplatesManagement.vue`
- `src/components/client/ProjectDashboardWidget.vue`
- `src/components/agent/modals/WidgetsModal.vue`
- `src/components/agent/modals/CreateProjectModal.vue`
- `src/components/agent/modals/TemplateModal.vue`
- `src/components/SuperAdmin/UserManager.vue`
- `src/components/ProjectManagement/TeamTab.vue`
- `src/components/ProjectManagement/ProgressEditor.vue`
- `src/components/ProjectManagement/EditProjectModal.vue`
- `src/components/ClientManagement.vue`
- `src/components/auth/LoginForm.vue`
- `src/components/examples/TranslationExample.vue`

## Avantages de l'Unification

### 🎯 Cohérence
- Une seule méthode d'accès aux traductions
- Pas de confusion entre `$t()` et `t()`
- Code plus prévisible

### 🔧 Maintenabilité
- Composition API native
- Meilleure intégration TypeScript
- Debugging plus facile

### ⚡ Performance
- Pas de propriétés globales
- Import explicite des dépendances
- Tree-shaking optimisé

### 🧪 Testabilité
- Mocking plus simple
- Tests unitaires plus clairs
- Isolation des composants

## Bonnes Pratiques

### ✅ À Faire

```javascript
// Import explicite
import { useTranslation } from '../composables/useTranslation'

// Utilisation dans setup()
const { t } = useTranslation()

// Exposition dans le return
return { t }
```

### ❌ À Éviter

```javascript
// Plus de propriétés globales
this.$t('key') // ❌ Supprimé

// Accès direct au service
import translationService from '../services/translationService' // ❌ Éviter
```

## Dépannage

### Erreur "t is not defined"

```javascript
// Solution: Ajouter l'import et l'utilisation
import { useTranslation } from '../composables/useTranslation'

export default {
  setup() {
    const { t } = useTranslation()
    return { t }
  }
}
```

### Erreur "Cannot read property 't' of undefined"

```javascript
// Vérifier que t est bien exposé dans le return
return {
  // autres propriétés...
  t // ← Important !
}
```

## Scripts de Maintenance

### Vérification de la Migration

```bash
# Vérifier qu'il n'y a plus de $t() dans le code
grep -r "\$t(" src/ || echo "✅ Aucun $t() trouvé"

# Vérifier les imports useTranslation
grep -r "useTranslation" src/ | wc -l
```

### Re-exécution de la Migration

```bash
# Si nécessaire, re-exécuter la migration
node scripts/unify-translation-system.cjs
```

## Ressources

- **Service principal** : `src/services/translationService.js`
- **Store Pinia** : `src/stores/translation.js`
- **Composable** : `src/composables/useTranslation.js`
- **Plugin Vue** : `src/plugins/translation.js`
- **Fichiers de langue** : `src/lang/`
- **Script de migration** : `scripts/unify-translation-system.cjs`

---

**Note** : Ce système unifié garantit une meilleure cohérence, maintenabilité et performance pour l'internationalisation de l'application.