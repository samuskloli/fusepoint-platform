/**
 * Script de diagnostic pour le problème de création de client
 */

const axios = require('axios');

// Configuration de base
const BASE_URL = 'http://localhost:3000';
const FRONTEND_URL = 'http://localhost:5173';

// Données de test pour un nouveau client
const testClientData = {
  first_name: 'Test',
  last_name: 'Client',
  email: 'test.client@example.com',
  phone: '+33123456789',
  company: 'Test Company',
  status: 'active'
};

async function testClientCreation() {
  console.log('🔍 Diagnostic du problème de création de client...');
  
  try {
    // Test 1: Vérifier la connexion au serveur
    console.log('\n1. Test de connexion au serveur...');
    const healthCheck = await axios.get(`${BASE_URL}/api/health`);
    console.log('✅ Serveur accessible:', healthCheck.status);
    
  } catch (error) {
    console.log('❌ Erreur de connexion serveur:', error.message);
  }
  
  try {
    // Test 2: Vérifier l'endpoint de création de client
    console.log('\n2. Test de l\'endpoint de création de client...');
    
    // Simuler une requête POST vers l'endpoint de création
    const response = await axios.post(`${BASE_URL}/api/agent/clients`, testClientData, {
      headers: {
        'Content-Type': 'application/json',
        // Note: En production, il faudrait un token d'authentification
      }
    });
    
    console.log('✅ Client créé avec succès:', response.data);
    
  } catch (error) {
    console.log('❌ Erreur lors de la création du client:');
    console.log('Status:', error.response?.status);
    console.log('Message:', error.response?.data?.message || error.message);
    console.log('Détails:', error.response?.data);
  }
  
  try {
    // Test 3: Vérifier la liste des clients
    console.log('\n3. Test de récupération de la liste des clients...');
    const clientsList = await axios.get(`${BASE_URL}/api/agent/clients`);
    console.log('✅ Liste des clients récupérée:', clientsList.data?.length || 0, 'clients');
    
  } catch (error) {
    console.log('❌ Erreur lors de la récupération des clients:', error.message);
  }
}

// Fonction pour tester les fichiers frontend
function checkFrontendFiles() {
  console.log('\n🔍 Vérification des fichiers frontend...');
  
  const fs = require('fs');
  const path = require('path');
  
  const filesToCheck = [
    'src/views/AgentClients.vue',
    'src/composables/useClientManagement.js',
    'src/services/clientManagementService.js',
    'src/components/ClientModal.vue'
  ];
  
  filesToCheck.forEach(file => {
    const fullPath = path.join(__dirname, file);
    if (fs.existsSync(fullPath)) {
      console.log('✅', file, 'existe');
    } else {
      console.log('❌', file, 'manquant');
    }
  });
}

// Exécution du diagnostic
async function runDiagnostic() {
  console.log('🚀 Début du diagnostic de création de client\n');
  
  checkFrontendFiles();
  await testClientCreation();
  
  console.log('\n📋 Résumé du diagnostic:');
  console.log('- Vérifiez que l\'authentification est correcte');
  console.log('- Vérifiez que les événements Vue sont bien liés');
  console.log('- Vérifiez la console du navigateur pour les erreurs JavaScript');
  console.log('- Vérifiez que le modal s\'ouvre correctement');
}

runDiagnostic().catch(console.error);