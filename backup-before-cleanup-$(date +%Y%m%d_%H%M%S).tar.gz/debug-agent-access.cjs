const axios = require('axios');
const jwt = require('jsonwebtoken');

// Configuration
const BASE_URL = 'http://localhost:3003';
// Utiliser le même JWT_SECRET que le serveur
const JWT_SECRET = 'c562c4171abd11ef5a40aa858d7702db810d2adcfdcd64a6e1af8bb4243c28c9';

// Fonction pour créer un token JWT de test
function createTestToken(userData) {
  return jwt.sign(userData, JWT_SECRET, { expiresIn: '1h' });
}

// Fonction pour tester l'accès aux routes agent
async function testAgentAccess() {
  console.log('🔍 Test d\'accès au tableau de bord agent');
  console.log('=' .repeat(50));

  // Cas de test avec différents rôles
  const testCases = [
    {
      name: 'Utilisateur avec rôle agent',
      userData: {
        id: 1,
        email: 'agent@test.com',
        role: 'agent',
        company_id: 1
      }
    },
    {
      name: 'Utilisateur avec rôle super_admin',
      userData: {
        id: 2,
        email: 'superadmin@test.com',
        role: 'super_admin',
        company_id: 1
      }
    },
    {
      name: 'Utilisateur avec rôle admin',
      userData: {
        id: 3,
        email: 'admin@test.com',
        role: 'admin',
        company_id: 1
      }
    },
    {
      name: 'Utilisateur avec rôle user (non autorisé)',
      userData: {
        id: 4,
        email: 'user@test.com',
        role: 'user',
        company_id: 1
      }
    }
  ];

  // Routes à tester
  const routesToTest = [
    '/api/agent/stats',
    '/api/agent/clients',
    '/api/agent/assigned-clients',
    '/api/agent/available'
  ];

  for (const testCase of testCases) {
    console.log(`\n📋 Test: ${testCase.name}`);
    console.log(`   Rôle: ${testCase.userData.role}`);
    
    const token = createTestToken(testCase.userData);
    
    for (const route of routesToTest) {
      try {
        const response = await axios.get(`${BASE_URL}${route}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          timeout: 5000
        });
        
        console.log(`   ✅ ${route}: ${response.status} - Accès autorisé`);
      } catch (error) {
        if (error.response) {
          const status = error.response.status;
          const message = error.response.data?.message || 'Erreur inconnue';
          
          if (status === 401) {
            console.log(`   ❌ ${route}: ${status} - Non authentifié`);
          } else if (status === 403) {
            console.log(`   ❌ ${route}: ${status} - Accès refusé (${message})`);
          } else {
            console.log(`   ⚠️  ${route}: ${status} - ${message}`);
          }
        } else {
          console.log(`   💥 ${route}: Erreur de connexion - ${error.message}`);
        }
      }
    }
  }
}

// Fonction pour vérifier la structure du token
function verifyTokenStructure() {
  console.log('\n🔍 Vérification de la structure des tokens');
  console.log('=' .repeat(50));
  
  const testUserData = {
    id: 1,
    email: 'agent@test.com',
    role: 'agent',
    company_id: 1
  };
  
  const token = createTestToken(testUserData);
  console.log('Token généré:', token.substring(0, 50) + '...');
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log('Token décodé:', JSON.stringify(decoded, null, 2));
  } catch (error) {
    console.error('Erreur de décodage du token:', error.message);
  }
}

// Fonction principale
async function main() {
  try {
    console.log('🚀 Démarrage des tests d\'accès agent');
    console.log(`🌐 URL de base: ${BASE_URL}`);
    
    // Vérifier que le serveur est accessible
    try {
      console.log('🔍 Test de connexion au serveur...');
      const response = await axios.get(`${BASE_URL}/health`, { timeout: 5000 });
      console.log('✅ Serveur accessible - Status:', response.status);
      console.log('📊 Réponse santé:', response.data);
    } catch (error) {
      console.error('❌ Serveur non accessible');
      console.error('   Code d\'erreur:', error.code);
      console.error('   Message:', error.message);
      if (error.response) {
        console.error('   Status HTTP:', error.response.status);
        console.error('   Données:', error.response.data);
      }
      console.log('\n🔧 Vérifications suggérées:');
      console.log('   1. Le serveur backend est-il démarré ?');
      console.log('   2. Le port 3003 est-il libre ?');
      console.log('   3. Vérifiez les logs du serveur');
      return;
    }
    
    verifyTokenStructure();
    await testAgentAccess();
    
    console.log('\n🏁 Tests terminés');
  } catch (error) {
    console.error('💥 Erreur lors des tests:', error);
  }
}

// Exécuter les tests
if (require.main === module) {
  main();
}

module.exports = { testAgentAccess, verifyTokenStructure };