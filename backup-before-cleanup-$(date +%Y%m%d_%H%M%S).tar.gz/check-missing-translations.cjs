const fs = require('fs');
const path = require('path');

// Lire le fichier ClientProjectDashboard.vue
const dashboardFile = fs.readFileSync(
  path.join(__dirname, 'src/views/ClientProjectDashboard.vue'),
  'utf8'
);

// Extraire toutes les clés de traduction utilisées
const translationKeys = [];
const tRegex = /t\(['"`]([^'"`,)]+)['"`]/g;
let match;

while ((match = tRegex.exec(dashboardFile)) !== null) {
  translationKeys.push(match[1]);
}

console.log('🔍 Clés de traduction trouvées dans ClientProjectDashboard.vue:');
translationKeys.forEach(key => console.log(`  - ${key}`));

// Lire le fichier de traduction français
try {
  const frTranslations = require('./src/langold/fr.js');
  
  console.log('\n❌ Clés manquantes dans fr.js:');
  const missingKeys = [];
  
  translationKeys.forEach(key => {
    const keyParts = key.split('.');
    let current = frTranslations.default || frTranslations;
    let exists = true;
    
    for (const part of keyParts) {
      if (current && typeof current === 'object' && current[part] !== undefined) {
        current = current[part];
      } else {
        exists = false;
        break;
      }
    }
    
    if (!exists) {
      missingKeys.push(key);
      console.log(`  - ${key}`);
    }
  });
  
  if (missingKeys.length === 0) {
    console.log('  ✅ Toutes les clés sont présentes!');
  } else {
    console.log(`\n📊 Total: ${missingKeys.length} clés manquantes sur ${translationKeys.length}`);
    
    // Générer la structure JSON manquante
    console.log('\n🔧 Structure JSON à ajouter dans fr.js:');
    const structure = {};
    
    missingKeys.forEach(key => {
      const parts = key.split('.');
      let current = structure;
      
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (i === parts.length - 1) {
          current[part] = `[TRADUCTION MANQUANTE: ${key}]`;
        } else {
          if (!current[part]) current[part] = {};
          current = current[part];
        }
      }
    });
    
    console.log(JSON.stringify(structure, null, 2));
  }
  
} catch (error) {
  console.error('❌ Erreur lors de la lecture du fichier de traduction:', error.message);
}