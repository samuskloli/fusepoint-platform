const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function testAgentAssignment() {
  console.log('🧪 Test d\'assignation d\'agent...');
  
  try {
    // Étape 1: Se connecter et obtenir un token
    console.log('\n1️⃣ Connexion...');
    const loginCommand = `curl -s -X POST http://localhost:3002/api/auth/login \
      -H "Content-Type: application/json" \
      -d '{"email":"admin@fusepoint.com","password":"admin123"}'`;
    
    const { stdout: loginResponse } = await execPromise(loginCommand);
    const loginData = JSON.parse(loginResponse);
    
    if (!loginData.success) {
      throw new Error('Échec de la connexion');
    }
    
    const accessToken = loginData.tokens?.accessToken || loginData.accessToken;
    if (!accessToken) {
      throw new Error('Token d\'accès non reçu');
    }
    
    console.log('✅ Connexion réussie, token reçu');
    
    // Étape 2: Récupérer les agents disponibles
    console.log('\n2️⃣ Récupération des agents disponibles...');
    const agentsCommand = `curl -s -X GET http://localhost:3002/api/agent/available \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json"`;
    
    const { stdout: agentsResponse } = await execPromise(agentsCommand);
    const agentsData = JSON.parse(agentsResponse);
    
    if (!agentsData.success || !agentsData.agents || agentsData.agents.length === 0) {
      throw new Error('Aucun agent disponible trouvé');
    }
    
    console.log(`✅ ${agentsData.agents.length} agent(s) disponible(s):`);
    agentsData.agents.forEach(agent => {
      console.log(`   - ID: ${agent.id}, Nom: ${agent.first_name} ${agent.last_name}, Email: ${agent.email}`);
    });
    
    // Étape 3: Tester l'assignation d'agent
    const agentId = agentsData.agents[0].id;
    const clientId = 35; // Samuel Oliveira
    
    console.log(`\n3️⃣ Test d'assignation de l'agent ${agentId} au client ${clientId}...`);
    const assignCommand = `curl -s -X POST http://localhost:3002/api/client/${clientId}/assign-agent \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json" \
      -d '{"agentId":${agentId}}'`;
    
    const { stdout: assignResponse } = await execPromise(assignCommand);
    const assignData = JSON.parse(assignResponse);
    
    if (assignData.success) {
      console.log('✅ Assignation réussie!');
      console.log(`   Client: ${assignData.client?.first_name} ${assignData.client?.last_name}`);
      console.log(`   Agent: ${assignData.agent?.first_name} ${assignData.agent?.last_name}`);
    } else {
      console.log('❌ Échec de l\'assignation:', assignData.message || 'Erreur inconnue');
    }
    
    // Étape 4: Vérifier l'assignation
    console.log('\n4️⃣ Vérification de l\'assignation...');
    const verifyCommand = `curl -s -X GET http://localhost:3002/api/agent/assigned-clients \
      -H "Authorization: Bearer ${accessToken}" \
      -H "Content-Type: application/json"`;
    
    const { stdout: verifyResponse } = await execPromise(verifyCommand);
    const verifyData = JSON.parse(verifyResponse);
    
    if (verifyData.success && verifyData.clients && verifyData.clients.length > 0) {
      console.log(`✅ ${verifyData.clients.length} client(s) assigné(s) trouvé(s):`);
      verifyData.clients.forEach(client => {
        console.log(`   - ${client.first_name} ${client.last_name} (${client.email})`);
      });
    } else {
      console.log('⚠️ Aucun client assigné trouvé');
    }
    
  } catch (error) {
    console.error('❌ Erreur lors du test:', error.message);
  }
}

testAgentAssignment();