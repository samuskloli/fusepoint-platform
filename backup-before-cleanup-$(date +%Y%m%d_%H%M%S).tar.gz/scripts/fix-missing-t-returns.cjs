#!/usr/bin/env node

const fs = require('fs')
const path = require('path')
const glob = require('glob')

class TranslationReturnFixer {
  constructor() {
    this.stats = {
      filesChecked: 0,
      filesFixed: 0,
      errors: []
    }
  }

  async run() {
    console.log('🔍 Recherche des composants Vue avec useTranslation...')
    
    const vueFiles = glob.sync('src/**/*.vue', { cwd: process.cwd() })
    
    for (const file of vueFiles) {
      await this.checkAndFixFile(file)
    }
    
    this.printStats()
  }

  async checkAndFixFile(filePath) {
    this.stats.filesChecked++
    
    try {
      const content = fs.readFileSync(filePath, 'utf8')
      
      // Vérifier si le fichier utilise useTranslation
      const usesUseTranslation = /import.*useTranslation.*from.*useTranslation/.test(content)
      if (!usesUseTranslation) return
      
      // Vérifier si t() est utilisé dans le template
      const usesT = /{{.*t\(|v-.*t\(|:.*t\(|@.*t\(/.test(content)
      if (!usesT) return
      
      // Vérifier si const { t } = useTranslation() existe
      const hasUseTranslationCall = /const.*{.*t.*}.*=.*useTranslation\(\)/.test(content)
      if (!hasUseTranslationCall) return
      
      // Vérifier si t est retourné dans le return
      const returnMatch = content.match(/return\s*{([^}]+)}/s)
      if (!returnMatch) return
      
      const returnContent = returnMatch[1]
      const hasReturnT = /\bt\b/.test(returnContent)
      
      if (!hasReturnT) {
        console.log(`🔧 Correction de ${filePath}...`)
        await this.fixFile(filePath, content, returnMatch)
        this.stats.filesFixed++
      }
      
    } catch (error) {
      this.stats.errors.push(`Erreur lors du traitement de ${filePath}: ${error.message}`)
    }
  }

  async fixFile(filePath, content, returnMatch) {
    const returnContent = returnMatch[1].trim()
    
    // Ajouter t à la fin du return (avant la dernière ligne)
    let newReturnContent
    if (returnContent.endsWith(',')) {
      newReturnContent = returnContent + '\n      t'
    } else {
      newReturnContent = returnContent + ',\n      t'
    }
    
    const newContent = content.replace(
      /return\s*{([^}]+)}/s,
      `return {${newReturnContent}\n    }`
    )
    
    fs.writeFileSync(filePath, newContent, 'utf8')
  }

  printStats() {
    console.log('\n📊 Statistiques:')
    console.log(`📁 Fichiers vérifiés: ${this.stats.filesChecked}`)
    console.log(`🔧 Fichiers corrigés: ${this.stats.filesFixed}`)
    
    if (this.stats.errors.length > 0) {
      console.log('\n❌ Erreurs:')
      this.stats.errors.forEach(error => console.log(`  ${error}`))
    }
    
    if (this.stats.filesFixed > 0) {
      console.log('\n✅ Correction terminée! Redémarrez le serveur pour appliquer les changements.')
    } else {
      console.log('\n✅ Aucune correction nécessaire.')
    }
  }
}

// Exécution
if (require.main === module) {
  const fixer = new TranslationReturnFixer()
  fixer.run().catch(console.error)
}

module.exports = TranslationReturnFixer