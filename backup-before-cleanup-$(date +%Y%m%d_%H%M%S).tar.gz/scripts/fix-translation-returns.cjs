#!/usr/bin/env node

/**
 * Script de correction pour exposer correctement la fonction t dans les returns
 */

const fs = require('fs')
const path = require('path')
const glob = require('glob')

class TranslationReturnFixer {
  constructor() {
    this.stats = {
      filesProcessed: 0,
      filesFixed: 0,
      returnsAdded: 0
    }
  }

  /**
   * Trouve tous les fichiers Vue
   */
  findVueFiles() {
    const srcPattern = path.join(process.cwd(), 'src/**/*.vue')
    return glob.sync(srcPattern)
  }

  /**
   * Vérifie si un fichier utilise t() mais ne l'expose pas
   */
  needsReturnFix(content) {
    const usesT = /\bt\(['"]/.test(content)
    const hasUseTranslationCall = /const.*{.*t.*}.*=.*useTranslation\(\)/.test(content)
    const returnMatch = content.match(/return\s*{([^}]*)}/)
    
    if (!usesT || !hasUseTranslationCall || !returnMatch) {
      return false
    }
    
    const returnContent = returnMatch[1]
    return !returnContent.includes('t,') && !returnContent.includes('t }') && !returnContent.includes('t\n')
  }

  /**
   * Corrige le return pour exposer t
   */
  fixReturn(content) {
    const returnMatch = content.match(/return\s*{([^}]*)}/)
    if (!returnMatch) {
      return content
    }
    
    const returnContent = returnMatch[1].trim()
    let newReturnContent
    
    if (returnContent === '') {
      // Return vide
      newReturnContent = 't'
    } else if (returnContent.endsWith(',')) {
      // Return se termine par une virgule
      newReturnContent = `${returnContent}\n      t`
    } else {
      // Return avec contenu
      newReturnContent = `${returnContent},\n      t`
    }
    
    const newReturn = `return {\n      ${newReturnContent}\n    }`
    return content.replace(/return\s*{[^}]*}/, newReturn)
  }

  /**
   * Traite un fichier
   */
  processFile(filePath) {
    this.stats.filesProcessed++
    
    let content = fs.readFileSync(filePath, 'utf8')
    const originalContent = content
    
    if (!this.needsReturnFix(content)) {
      return
    }
    
    console.log(`🔧 Correction de ${path.relative(process.cwd(), filePath)}`)
    
    content = this.fixReturn(content)
    
    if (content !== originalContent) {
      fs.writeFileSync(filePath, content, 'utf8')
      this.stats.filesFixed++
      this.stats.returnsAdded++
      console.log(`✅ Fichier corrigé: ${path.relative(process.cwd(), filePath)}`)
    }
  }

  /**
   * Lance la correction
   */
  run() {
    console.log('🔧 Correction des returns pour exposer la fonction t...\n')
    
    const vueFiles = this.findVueFiles()
    console.log(`📁 ${vueFiles.length} fichiers Vue trouvés\n`)
    
    vueFiles.forEach(filePath => {
      try {
        this.processFile(filePath)
      } catch (error) {
        console.error(`❌ Erreur lors du traitement de ${filePath}:`, error.message)
      }
    })
    
    this.printStats()
  }

  /**
   * Affiche les statistiques
   */
  printStats() {
    console.log('\n📊 Statistiques de correction:')
    console.log(`   • Fichiers traités: ${this.stats.filesProcessed}`)
    console.log(`   • Fichiers corrigés: ${this.stats.filesFixed}`)
    console.log(`   • Returns modifiés: ${this.stats.returnsAdded}`)
    console.log('\n✅ Correction terminée!')
  }
}

// Exécuter la correction
if (require.main === module) {
  const fixer = new TranslationReturnFixer()
  fixer.run()
}

module.exports = TranslationReturnFixer