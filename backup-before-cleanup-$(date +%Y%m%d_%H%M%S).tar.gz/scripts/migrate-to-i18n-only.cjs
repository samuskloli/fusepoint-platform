#!/usr/bin/env node

/**
 * Script de migration complète vers Vue I18n uniquement
 * Supprime l'ancien système de traduction personnalisé
 */

const fs = require('fs')
const path = require('path')
const { glob } = require('glob')

class I18nOnlyMigrator {
  constructor() {
    this.stats = {
      filesProcessed: 0,
      filesModified: 0,
      translationServiceRemoved: 0,
      useTranslationStoreRemoved: 0,
      directivesUpdated: 0
    }
  }

  async migrate() {
    console.log('🚀 Début de la migration vers Vue I18n uniquement...')
    
    // 1. Migrer les fichiers Vue et JS
    await this.migrateVueAndJsFiles()
    
    // 2. Supprimer les anciens fichiers
    await this.removeOldFiles()
    
    // 3. Mettre à jour les plugins
    await this.updatePlugins()
    
    // 4. Rapport final
    this.printReport()
  }

  async migrateVueAndJsFiles() {
    console.log('📁 Migration des fichiers Vue et JS...')
    
    const files = await glob('src/**/*.{vue,js}', {
      cwd: process.cwd(),
      ignore: [
        'src/services/translationService.js',
        'src/stores/translation.js',
        'src/plugins/translation.js',
        'src/composables/useTranslation.js',
        'src/plugins/i18n.js'
      ]
    })

    for (const file of files) {
      await this.processFile(file)
    }
  }

  async processFile(filePath) {
    const fullPath = path.resolve(filePath)
    const content = fs.readFileSync(fullPath, 'utf8')
    let modified = content
    let hasChanges = false

    this.stats.filesProcessed++

    // Remplacer les imports de translationService
    if (content.includes('translationService')) {
      // Supprimer l'import de translationService
      modified = modified.replace(
        /import\s+.*translationService.*from.*['"].*translationService.*['"];?\n?/g,
        ''
      )
      
      // Ajouter l'import useTranslation si pas déjà présent
      if (!modified.includes("import { useTranslation } from")) {
        const importMatch = modified.match(/import\s+.*?from\s+['"]/)
        if (importMatch) {
          const insertPos = modified.indexOf(importMatch[0])
          modified = modified.slice(0, insertPos) + 
            "import { useTranslation } from '@/composables/useTranslation'\n" +
            modified.slice(insertPos)
        }
      }
      
      // Remplacer const { t } = translationService par const { t } = useTranslation()
      modified = modified.replace(
        /const\s*{\s*t\s*}\s*=\s*translationService/g,
        'const { t } = useTranslation()'
      )
      
      hasChanges = true
      this.stats.translationServiceRemoved++
    }

    // Remplacer useTranslationStore
    if (content.includes('useTranslationStore')) {
      // Supprimer l'import de useTranslationStore
      modified = modified.replace(
        /import\s+.*useTranslationStore.*from.*['"].*translation.*['"];?\n?/g,
        ''
      )
      
      // Ajouter l'import useTranslation si pas déjà présent
      if (!modified.includes("import { useTranslation } from")) {
        const importMatch = modified.match(/import\s+.*?from\s+['"]/)
        if (importMatch) {
          const insertPos = modified.indexOf(importMatch[0])
          modified = modified.slice(0, insertPos) + 
            "import { useTranslation } from '@/composables/useTranslation'\n" +
            modified.slice(insertPos)
        }
      }
      
      // Remplacer useTranslationStore() par useTranslation()
      modified = modified.replace(
        /const\s+\w+\s*=\s*useTranslationStore\(\)/g,
        'const { t } = useTranslation()'
      )
      
      hasChanges = true
      this.stats.useTranslationStoreRemoved++
    }

    // Nettoyer les lignes vides multiples
    modified = modified.replace(/\n\s*\n\s*\n/g, '\n\n')

    if (hasChanges) {
      fs.writeFileSync(fullPath, modified)
      this.stats.filesModified++
      console.log(`✅ ${filePath}`)
    }
  }

  async removeOldFiles() {
    console.log('🗑️  Suppression des anciens fichiers...')
    
    const filesToRemove = [
      'src/services/translationService.js',
      'src/stores/translation.js',
      'src/plugins/translation.js'
    ]

    for (const file of filesToRemove) {
      const fullPath = path.resolve(file)
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath)
        console.log(`🗑️  Supprimé: ${file}`)
      }
    }
  }

  async updatePlugins() {
    console.log('🔧 Mise à jour des plugins...')
    
    // Vérifier que main.js utilise bien i18n
    const mainJsPath = path.resolve('src/main.js')
    if (fs.existsSync(mainJsPath)) {
      const content = fs.readFileSync(mainJsPath, 'utf8')
      if (!content.includes('import i18n from')) {
        console.log('⚠️  main.js ne semble pas importer i18n correctement')
      } else {
        console.log('✅ main.js utilise déjà Vue I18n')
      }
    }
  }

  printReport() {
    console.log('\n📊 Rapport de migration:')
    console.log(`📁 Fichiers traités: ${this.stats.filesProcessed}`)
    console.log(`✏️  Fichiers modifiés: ${this.stats.filesModified}`)
    console.log(`🔄 translationService supprimés: ${this.stats.translationServiceRemoved}`)
    console.log(`🔄 useTranslationStore supprimés: ${this.stats.useTranslationStoreRemoved}`)
    console.log('\n✅ Migration terminée! L\'application utilise maintenant uniquement Vue I18n.')
    console.log('\n📝 Prochaines étapes:')
    console.log('1. Tester l\'application')
    console.log('2. Vérifier que toutes les traductions fonctionnent')
    console.log('3. Supprimer les scripts de migration obsolètes')
  }
}

// Exécution du script
if (require.main === module) {
  const migrator = new I18nOnlyMigrator()
  migrator.migrate().catch(console.error)
}

module.exports = I18nOnlyMigrator