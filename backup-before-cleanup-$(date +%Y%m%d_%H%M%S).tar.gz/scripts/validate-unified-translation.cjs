#!/usr/bin/env node

/**
 * Script de validation du système de traduction unifié
 * Vérifie que la migration s'est bien passée et qu'il n'y a plus de conflits
 */

const fs = require('fs')
const path = require('path')
const glob = require('glob')

class TranslationValidator {
  constructor() {
    this.issues = []
    this.stats = {
      filesChecked: 0,
      vueFilesWithTranslations: 0,
      remainingGlobalT: 0,
      missingImports: 0,
      missingSetupUsage: 0
    }
  }

  /**
   * Trouve tous les fichiers Vue
   */
  findVueFiles() {
    const srcPattern = path.join(process.cwd(), 'src/**/*.vue')
    return glob.sync(srcPattern)
  }

  /**
   * Vérifie un fichier Vue
   */
  validateFile(filePath) {
    this.stats.filesChecked++
    
    const content = fs.readFileSync(filePath, 'utf8')
    const relativePath = path.relative(process.cwd(), filePath)
    
    // Vérifier s'il y a des traductions dans le fichier
    const hasTranslations = /\bt\(['"]/.test(content) || /v-t[=-]/.test(content)
    
    if (!hasTranslations) {
      return // Pas de traductions, pas besoin de vérifier
    }
    
    this.stats.vueFilesWithTranslations++
    
    // 1. Vérifier qu'il n'y a plus de $t()
    const globalTMatches = content.match(/\$t\(/g)
    if (globalTMatches) {
      this.stats.remainingGlobalT += globalTMatches.length
      this.issues.push({
        type: 'error',
        file: relativePath,
        message: `${globalTMatches.length} occurrence(s) de $t() trouvée(s). Utilisez t() à la place.`,
        line: this.getLineNumber(content, content.indexOf('$t('))
      })
    }
    
    // 2. Vérifier l'import useTranslation
    const hasUseTranslationImport = /import.*useTranslation.*from.*composables\/useTranslation/.test(content)
    const usesT = /\bt\(['"]/.test(content)
    
    if (usesT && !hasUseTranslationImport) {
      this.stats.missingImports++
      this.issues.push({
        type: 'error',
        file: relativePath,
        message: 'Utilise t() mais n\'importe pas useTranslation',
        suggestion: "Ajouter: import { useTranslation } from '../composables/useTranslation'"
      })
    }
    
    // 3. Vérifier l'utilisation dans setup()
    const hasSetupFunction = /setup\s*\([^)]*\)\s*{/.test(content)
    const hasUseTranslationCall = /const.*{.*t.*}.*=.*useTranslation\(\)/.test(content)
    
    if (usesT && hasSetupFunction && !hasUseTranslationCall) {
      this.stats.missingSetupUsage++
      this.issues.push({
        type: 'error',
        file: relativePath,
        message: 'Utilise t() mais n\'appelle pas useTranslation() dans setup()',
        suggestion: 'Ajouter: const { t } = useTranslation()'
      })
    }
    
    // 4. Vérifier que t est exposé dans le return
    const returnMatch = content.match(/return\s*{([^}]*)}/)
    if (usesT && hasSetupFunction && returnMatch) {
      const returnContent = returnMatch[1]
      if (!returnContent.includes('t,') && !returnContent.includes('t }') && !returnContent.includes('t\n')) {
        this.issues.push({
          type: 'warning',
          file: relativePath,
          message: 'Utilise t() mais ne l\'expose pas dans le return de setup()',
          suggestion: 'Ajouter t dans le return: return { ..., t }'
        })
      }
    }
    
    // 5. Vérifier les directives obsolètes
    const obsoleteDirectives = content.match(/v-t-text|v-translate/g)
    if (obsoleteDirectives) {
      this.issues.push({
        type: 'warning',
        file: relativePath,
        message: `Directive(s) obsolète(s) trouvée(s): ${obsoleteDirectives.join(', ')}`,
        suggestion: 'Utilisez v-t, v-t-placeholder ou v-t-title'
      })
    }
  }

  /**
   * Obtient le numéro de ligne d'une position
   */
  getLineNumber(content, position) {
    return content.substring(0, position).split('\n').length
  }

  /**
   * Vérifie la configuration du plugin
   */
  validatePlugin() {
    const pluginPath = path.join(process.cwd(), 'src/plugins/translation.js')
    
    if (!fs.existsSync(pluginPath)) {
      this.issues.push({
        type: 'error',
        file: 'src/plugins/translation.js',
        message: 'Fichier plugin de traduction manquant'
      })
      return
    }
    
    const content = fs.readFileSync(pluginPath, 'utf8')
    
    // Vérifier que les propriétés globales ont été supprimées
    if (content.includes('app.config.globalProperties.$t')) {
      this.issues.push({
        type: 'error',
        file: 'src/plugins/translation.js',
        message: 'Les propriétés globales $t sont encore présentes dans le plugin',
        suggestion: 'Supprimer les propriétés globales pour éviter les conflits'
      })
    }
    
    // Vérifier que les directives sont présentes
    if (!content.includes('app.directive(\'t\'')) {
      this.issues.push({
        type: 'warning',
        file: 'src/plugins/translation.js',
        message: 'Directive v-t manquante dans le plugin'
      })
    }
  }

  /**
   * Vérifie les fichiers de traduction
   */
  validateTranslationFiles() {
    const langDir = path.join(process.cwd(), 'src/lang')
    const requiredFiles = ['fr.js', 'en.js']
    
    for (const file of requiredFiles) {
      const filePath = path.join(langDir, file)
      if (!fs.existsSync(filePath)) {
        this.issues.push({
          type: 'error',
          file: `src/lang/${file}`,
          message: 'Fichier de traduction manquant'
        })
      }
    }
  }

  /**
   * Lance la validation
   */
  run() {
    console.log('🔍 Validation du système de traduction unifié...\n')
    
    // Valider les fichiers Vue
    const vueFiles = this.findVueFiles()
    console.log(`📁 Vérification de ${vueFiles.length} fichiers Vue...`)
    
    vueFiles.forEach(filePath => {
      try {
        this.validateFile(filePath)
      } catch (error) {
        this.issues.push({
          type: 'error',
          file: path.relative(process.cwd(), filePath),
          message: `Erreur lors de la validation: ${error.message}`
        })
      }
    })
    
    // Valider le plugin
    this.validatePlugin()
    
    // Valider les fichiers de traduction
    this.validateTranslationFiles()
    
    this.printResults()
  }

  /**
   * Affiche les résultats
   */
  printResults() {
    console.log('\n📊 Résultats de la validation:')
    console.log(`   • Fichiers vérifiés: ${this.stats.filesChecked}`)
    console.log(`   • Fichiers avec traductions: ${this.stats.vueFilesWithTranslations}`)
    console.log(`   • $t() restants: ${this.stats.remainingGlobalT}`)
    console.log(`   • Imports manquants: ${this.stats.missingImports}`)
    console.log(`   • Utilisations setup() manquantes: ${this.stats.missingSetupUsage}`)
    
    if (this.issues.length === 0) {
      console.log('\n✅ Aucun problème détecté ! Le système de traduction est unifié avec succès.')
      return
    }
    
    console.log(`\n⚠️  ${this.issues.length} problème(s) détecté(s):\n`)
    
    const errors = this.issues.filter(issue => issue.type === 'error')
    const warnings = this.issues.filter(issue => issue.type === 'warning')
    
    if (errors.length > 0) {
      console.log('❌ Erreurs:')
      errors.forEach((issue, index) => {
        console.log(`   ${index + 1}. ${issue.file}${issue.line ? `:${issue.line}` : ''}`)
        console.log(`      ${issue.message}`)
        if (issue.suggestion) {
          console.log(`      💡 ${issue.suggestion}`)
        }
        console.log()
      })
    }
    
    if (warnings.length > 0) {
      console.log('⚠️  Avertissements:')
      warnings.forEach((issue, index) => {
        console.log(`   ${index + 1}. ${issue.file}${issue.line ? `:${issue.line}` : ''}`)
        console.log(`      ${issue.message}`)
        if (issue.suggestion) {
          console.log(`      💡 ${issue.suggestion}`)
        }
        console.log()
      })
    }
    
    if (errors.length > 0) {
      console.log('❌ Validation échouée. Corrigez les erreurs ci-dessus.')
      process.exit(1)
    } else {
      console.log('✅ Validation réussie avec quelques avertissements.')
    }
  }
}

// Exécuter la validation
if (require.main === module) {
  const validator = new TranslationValidator()
  validator.run()
}

module.exports = TranslationValidator