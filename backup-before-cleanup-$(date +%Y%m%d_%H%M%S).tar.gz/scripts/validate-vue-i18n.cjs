const fs = require('fs')
const path = require('path')
const glob = require('glob')

class VueI18nValidator {
  constructor() {
    this.stats = {
      filesChecked: 0,
      vueFilesWithTranslations: 0,
      errors: [],
      warnings: []
    }
  }

  // Trouver tous les fichiers Vue
  findVueFiles() {
    return glob.sync('src/**/*.vue')
  }

  // Valider un fichier
  validateFile(filePath) {
    this.stats.filesChecked++
    
    const content = fs.readFileSync(filePath, 'utf8')
    const relativePath = path.relative(process.cwd(), filePath)
    
    // Vérifier s'il y a des traductions dans le fichier
    const hasTranslations = /\bt\(['"]/g.test(content) || /v-t[=-]/g.test(content)
    
    if (!hasTranslations) {
      return // Pas de traductions, pas besoin de vérifier
    }
    
    this.stats.vueFilesWithTranslations++
    
    // 1. Vérifier qu'il n'y a plus d'anciens imports
    this.checkOldImports(content, relativePath)
    
    // 2. Vérifier que useTranslation est importé si t() est utilisé
    this.checkTranslationImport(content, relativePath)
    
    // 3. Vérifier que useTranslation() est appelé dans setup()
    this.checkUseTranslationCall(content, relativePath)
    
    // 4. Vérifier que t est exposé dans le return de setup()
    this.checkTExposure(content, relativePath)
    
    // 5. Vérifier les directives obsolètes
    this.checkObsoleteDirectives(content, relativePath)
  }

  checkOldImports(content, filePath) {
    // Vérifier les anciens imports
    const oldImports = [
      /import.*translationService/,
      /import.*useTranslationStore/,
      /from.*translation.*store/
    ]
    
    oldImports.forEach(pattern => {
      if (pattern.test(content)) {
        this.stats.errors.push(`${filePath}: Ancien import de traduction détecté`)
      }
    })
  }

  checkTranslationImport(content, filePath) {
    const usesT = /\bt\(['"]/g.test(content)
    const hasImport = /import.*useTranslation.*from.*useTranslation/g.test(content)
    
    if (usesT && !hasImport) {
      this.stats.errors.push(`${filePath}: Utilise t() mais n'importe pas useTranslation`)
    }
  }

  checkUseTranslationCall(content, filePath) {
    const usesT = /\bt\(['"]/g.test(content)
    const hasUseTranslationCall = /useTranslation\(\)/g.test(content)
    
    if (usesT && !hasUseTranslationCall) {
      this.stats.errors.push(`${filePath}: Utilise t() mais n'appelle pas useTranslation() dans setup()`)
    }
  }

  checkTExposure(content, filePath) {
    const usesT = /\bt\(['"]/g.test(content)
    const hasSetupFunction = /setup\s*\(/g.test(content)
    
    if (usesT && hasSetupFunction) {
      // Vérifier que t est dans le return
      const setupMatch = content.match(/setup\s*\([^)]*\)\s*\{([\s\S]*?)\n\s*return\s*\{([\s\S]*?)\}/)
      if (setupMatch) {
        const returnContent = setupMatch[2]
        if (!returnContent.includes('t')) {
          this.stats.errors.push(`${filePath}: Utilise t() mais ne l'expose pas dans le return de setup()`)
        }
      }
    }
  }

  checkObsoleteDirectives(content, filePath) {
    // Vérifier les anciennes directives qui pourraient ne plus fonctionner
    const obsoletePatterns = [
      /v-t-html/g,
      /\$t\(/g // Vérifier s'il reste des $t()
    ]
    
    obsoletePatterns.forEach(pattern => {
      if (pattern.test(content)) {
        this.stats.warnings.push(`${filePath}: Directive ou fonction obsolète détectée`)
      }
    })
  }

  // Vérifier la configuration
  validateConfiguration() {
    console.log('🔍 Vérification de la configuration Vue I18n...')
    
    // Vérifier que le plugin i18n existe
    const i18nPluginPath = 'src/plugins/i18n.js'
    if (!fs.existsSync(i18nPluginPath)) {
      this.stats.errors.push('Plugin i18n.js manquant')
    }
    
    // Vérifier que main.js utilise le bon plugin
    const mainJsPath = 'src/main.js'
    if (fs.existsSync(mainJsPath)) {
      const mainContent = fs.readFileSync(mainJsPath, 'utf8')
      if (!mainContent.includes('from \'./plugins/i18n\'')) {
        this.stats.errors.push('main.js n\'importe pas le plugin i18n')
      }
      if (mainContent.includes('TranslationPlugin')) {
        this.stats.warnings.push('main.js contient encore une référence à l\'ancien TranslationPlugin')
      }
    }
    
    // Vérifier que les fichiers de langue existent
    const langFiles = ['src/lang/fr.js', 'src/lang/en.js']
    langFiles.forEach(file => {
      if (!fs.existsSync(file)) {
        this.stats.errors.push(`Fichier de langue manquant: ${file}`)
      }
    })
    
    // Vérifier que le composable useTranslation existe
    const composablePath = 'src/composables/useTranslation.js'
    if (!fs.existsSync(composablePath)) {
      this.stats.errors.push('Composable useTranslation.js manquant')
    } else {
      const composableContent = fs.readFileSync(composablePath, 'utf8')
      if (!composableContent.includes('useI18n')) {
        this.stats.errors.push('Le composable useTranslation n\'utilise pas useI18n')
      }
    }
  }

  // Exécuter la validation
  run() {
    console.log('🔍 Validation de la migration Vue I18n...')
    console.log()
    
    // Valider la configuration
    this.validateConfiguration()
    
    // Valider les fichiers Vue
    const files = this.findVueFiles()
    console.log(`📁 ${files.length} fichiers Vue trouvés`)
    console.log()
    
    files.forEach(file => {
      try {
        this.validateFile(file)
      } catch (error) {
        this.stats.errors.push(`Erreur lors de la validation de ${file}: ${error.message}`)
      }
    })
    
    // Afficher les résultats
    console.log('📊 Résultats de la validation:')
    console.log(`   Fichiers vérifiés: ${this.stats.filesChecked}`)
    console.log(`   Fichiers avec traductions: ${this.stats.vueFilesWithTranslations}`)
    console.log(`   Erreurs: ${this.stats.errors.length}`)
    console.log(`   Avertissements: ${this.stats.warnings.length}`)
    console.log()
    
    // Afficher les erreurs
    if (this.stats.errors.length > 0) {
      console.log('❌ Erreurs détectées:')
      this.stats.errors.forEach(error => {
        console.log(`   • ${error}`)
      })
      console.log()
    }
    
    // Afficher les avertissements
    if (this.stats.warnings.length > 0) {
      console.log('⚠️  Avertissements:')
      this.stats.warnings.forEach(warning => {
        console.log(`   • ${warning}`)
      })
      console.log()
    }
    
    // Conclusion
    if (this.stats.errors.length === 0) {
      console.log('✅ Migration Vue I18n validée avec succès!')
      if (this.stats.warnings.length > 0) {
        console.log('ℹ️  Quelques avertissements à vérifier, mais la migration semble fonctionnelle.')
      }
    } else {
      console.log('❌ Des erreurs ont été détectées. Veuillez les corriger avant de continuer.')
      process.exit(1)
    }
  }
}

// Exécuter la validation
if (require.main === module) {
  const validator = new VueI18nValidator()
  validator.run()
}

module.exports = VueI18nValidator