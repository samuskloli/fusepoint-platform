const fs = require('fs');
const path = require('path');

const frPath = path.join(__dirname, 'src/lang/fr.js');

try {
  const content = fs.readFileSync(frPath, 'utf8');
  
  // Chercher la section projects
  const projectsMatch = content.match(/projects:\s*\{([\s\S]*?)\n\s*\},?\s*\n/);
  
  if (projectsMatch) {
    console.log('📋 Section projects trouvée:');
    console.log('projects: {' + projectsMatch[1] + '\n}');
  } else {
    console.log('❌ Section projects non trouvée');
    
    // Chercher toutes les occurrences de "projects"
    const allMatches = content.match(/projects[^\n]*/g);
    if (allMatches) {
      console.log('🔍 Occurrences de "projects" trouvées:');
      allMatches.forEach(match => console.log('  -', match));
    }
  }
  
  // Chercher spécifiquement "dashboard"
  const dashboardMatches = content.match(/dashboard[^\n]*/g);
  if (dashboardMatches) {
    console.log('\n🎯 Occurrences de "dashboard" trouvées:');
    dashboardMatches.forEach(match => console.log('  -', match));
  }
  
} catch (error) {
  console.error('❌ Erreur:', error.message);
}