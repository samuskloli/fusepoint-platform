const fs = require('fs');
const path = require('path');

const frPath = path.join(__dirname, 'src/lang/fr.js');

try {
  const content = fs.readFileSync(frPath, 'utf8');
  const lines = content.split('\n');
  
  // Trouver toutes les occurrences de "projects:"
  const projectsLines = [];
  lines.forEach((line, index) => {
    if (line.includes('projects:')) {
      projectsLines.push({ line: index + 1, content: line });
    }
  });
  
  console.log('📋 Occurrences de "projects:":');
  projectsLines.forEach(p => {
    console.log(`Ligne ${p.line}: ${p.content.trim()}`);
  });
  
  // Examiner la première section projects
  if (projectsLines.length > 0) {
    const firstProjectsLine = projectsLines[0].line - 1; // Index 0-based
    console.log('\n🔍 Contenu autour de la première section projects:');
    
    const start = Math.max(0, firstProjectsLine - 2);
    const end = Math.min(lines.length, firstProjectsLine + 100);
    
    for (let i = start; i < end; i++) {
      const marker = i === firstProjectsLine ? ' >>> ' : '     ';
      console.log(`${marker}${i + 1}: ${lines[i]}`);
      
      // Arrêter à la fermeture de la section projects
      if (i > firstProjectsLine && lines[i].match(/^\s*\},?\s*$/)) {
        console.log('     ... (fin de section détectée)');
        break;
      }
    }
  }
  
} catch (error) {
  console.error('❌ Erreur:', error.message);
}