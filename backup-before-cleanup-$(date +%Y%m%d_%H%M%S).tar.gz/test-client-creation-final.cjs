const axios = require('axios');

const API_BASE_URL = 'http://localhost:3003/api';

async function testClientCreation() {
  try {
    console.log('🔐 Test de connexion...');
    
    // 1. Se connecter pour obtenir un token
    const loginResponse = await axios.post(`${API_BASE_URL}/auth/login`, {
      email: 'admin@fusepoint.com',
      password: 'admin123'
    });
    
    console.log('✅ Connexion réussie');
    const token = loginResponse.data.tokens.accessToken;
    console.log('Token reçu:', token ? 'Oui' : 'Non');
    
    // 2. Tester la création de client avec les bons champs
    console.log('📝 Test de création de client...');
    
    const clientData = {
      firstName: 'Jean',
      lastName: 'Dupont',
      email: 'jean.dupont@example.com',
      phone: '+33123456789',
      companyName: 'Entreprise Test',
      isActive: true
    };
    
    console.log('Données envoyées:', JSON.stringify(clientData, null, 2));
    
    const createResponse = await axios.post(`${API_BASE_URL}/agent/clients`, clientData, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Client créé avec succès!');
    console.log('Réponse:', JSON.stringify(createResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Erreur:', error.response?.status, error.response?.statusText);
    console.error('Message:', error.response?.data?.message || error.message);
    if (error.response?.data?.errors) {
      console.error('Erreurs de validation:', error.response.data.errors);
    }
  }
}

testClientCreation();