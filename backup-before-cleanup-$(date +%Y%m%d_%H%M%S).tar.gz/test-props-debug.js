// Test pour vérifier la logique de passage des props

// Simulation de la fonction editTemplate de ProjectTemplatesManagement.vue
function testEditTemplate() {
    const template = {
        id: 1,
        name: 'Template Test',
        description: 'Description test',
        duration_estimate: 45,
        category: 'marketing',
        tags: 'test, debug',
        is_active: true
    };
    
    console.log('=== TEMPLATE ORIGINAL ===');
    console.log(template);
    
    // Copie profonde comme dans editTemplate
    const selectedTemplate = JSON.parse(JSON.stringify(template));
    
    console.log('=== SELECTED TEMPLATE (copie) ===');
    console.log(selectedTemplate);
    
    // Vérification que la copie est correcte
    console.log('=== COMPARAISON ===');
    console.log('Nom original:', template.name);
    console.log('Nom copie:', selectedTemplate.name);
    console.log('Égalité:', template.name === selectedTemplate.name);
    
    // Test de modification de la copie
    selectedTemplate.name = 'Template Modifié';
    console.log('=== APRÈS MODIFICATION ===');
    console.log('Nom original:', template.name);
    console.log('Nom copie:', selectedTemplate.name);
    
    return selectedTemplate;
}

// Test de la logique d'initialisation du formulaire
function testInitializeForm(isEdit, template) {
    console.log('=== TEST INITIALIZE FORM ===');
    console.log('isEdit:', isEdit);
    console.log('template:', template);
    console.log('template type:', typeof template);
    
    const form = {
        name: '',
        description: '',
        duration_estimate: 30,
        category: '',
        tags: '',
        is_active: true
    };
    
    if (isEdit && template) {
        console.log('=== MODE ÉDITION ===');
        form.name = template.name || '';
        form.description = template.description || '';
        form.duration_estimate = Number(template.duration_estimate) || 30;
        form.category = template.category || '';
        form.tags = Array.isArray(template.tags)
            ? template.tags.join(', ')
            : (template.tags || '');
        form.is_active = Boolean(template.is_active);
    } else {
        console.log('=== MODE CRÉATION ===');
    }
    
    console.log('=== FORM FINAL ===');
    console.log(form);
    
    return form;
}

// Exécution des tests
console.log('\n=== DÉBUT DES TESTS ===\n');

const selectedTemplate = testEditTemplate();
console.log('\n');
testInitializeForm(true, selectedTemplate);

console.log('\n=== FIN DES TESTS ===');