import axios from 'axios';

const BASE_URL = 'http://localhost:3003';

// Fonction pour se connecter et obtenir un token
async function login() {
  try {
    console.log('🔐 Tentative de connexion...');
    
    // Essayer avec un utilisateur admin par défaut
    const loginData = {
      email: 'admin@fusepoint.com',
      password: 'admin123' // Mot de passe par défaut
    };
    
    const response = await axios.post(`${BASE_URL}/api/auth/login`, loginData);
    
    console.log('📋 Réponse complète:', JSON.stringify(response.data, null, 2));
    
    if (response.data.success) {
      console.log('✅ Connexion réussie');
      const token = response.data.tokens?.accessToken || response.data.token || response.data.accessToken;
      console.log('Token:', token ? 'Token récupéré avec succès' : 'Token non trouvé');
      return token;
    } else {
      console.log('❌ Échec de connexion:', response.data.message);
      return null;
    }
  } catch (error) {
    console.error('❌ Erreur de connexion:', error.response?.data || error.message);
    return null;
  }
}

// Fonction pour lister les projets
async function listProjects(token) {
  try {
    console.log('📋 Récupération de la liste des projets...');
    
    const response = await axios.get(`${BASE_URL}/api/agent/projects`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('✅ Projets récupérés:', response.data);
    return response.data.data?.projects || response.data.projects || response.data;
  } catch (error) {
    console.error('❌ Erreur récupération projets:', error.response?.data || error.message);
    return [];
  }
}

// Fonction pour tester la mise à jour d'un projet
async function testProjectUpdate(token, projectId) {
  try {
    console.log(`🔄 Test de mise à jour du projet ${projectId}...`);
    
    const updateData = {
      name: 'Projet Test Modifié - ' + new Date().toISOString(),
      description: 'Description mise à jour via test automatique',
      deadline: '2025-12-31',
      budget: 5000,
      priority: 'high',
      status: 'active'
    };
    
    console.log('📤 Données envoyées:', updateData);
    
    const response = await axios.put(`${BASE_URL}/api/agent/projects/${projectId}`, updateData, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Mise à jour réussie:', response.data);
    return response.data;
  } catch (error) {
    console.error('❌ Erreur mise à jour projet:', error.response?.data || error.message);
    return null;
  }
}

// Fonction principale
async function main() {
  console.log('🚀 Démarrage du test complet...');
  
  // 1. Se connecter
  const token = await login();
  if (!token) {
    console.log('❌ Impossible de continuer sans token');
    return;
  }
  
  // 2. Lister les projets
  const projects = await listProjects(token);
  if (projects.length === 0) {
    console.log('⚠️ Aucun projet trouvé');
    return;
  }
  
  console.log(`📊 ${projects.length} projet(s) trouvé(s)`);
  const firstProject = projects[0];
  console.log('🎯 Test avec le projet:', firstProject.id, '-', firstProject.name);
  
  // 3. Tester la mise à jour
  await testProjectUpdate(token, firstProject.id);
  
  console.log('🏁 Test terminé');
}

// Exécuter le test
main().catch(console.error);