#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Fonction pour trouver tous les fichiers Vue dans src/
function findVueFiles(dir) {
  const files = [];
  
  function traverse(currentDir) {
    const items = fs.readdirSync(currentDir);
    
    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        traverse(fullPath);
      } else if (item.endsWith('.vue')) {
        files.push(fullPath);
      }
    }
  }
  
  traverse(dir);
  return files;
}

// Fonction pour corriger un fichier
function fixFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;
    
    // Remplacer l'import de translationService
    if (content.includes("import translationService from '@/services/translationService'")) {
      content = content.replace(
        /import translationService from '@\/services\/translationService'/g,
        "import { useTranslation } from '@/composables/useTranslation'"
      );
      modified = true;
    }
    
    // Remplacer l'utilisation de translationService.t.bind
    if (content.includes('translationService.t.bind(translationService)')) {
      content = content.replace(
        /const t = translationService\.t\.bind\(translationService\)/g,
        'const { t } = useTranslation()'
      );
      modified = true;
    }
    
    // Ajouter l'import useTranslation si nécessaire
    if (modified && !content.includes("import { useTranslation }")) {
      // Trouver la ligne d'import Vue
      const vueImportMatch = content.match(/import \{[^}]+\} from 'vue'/);
      if (vueImportMatch) {
        const vueImportLine = vueImportMatch[0];
        content = content.replace(
          vueImportLine,
          vueImportLine + "\nimport { useTranslation } from '@/composables/useTranslation'"
        );
      }
    }
    
    if (modified) {
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`✅ Corrigé: ${filePath}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`❌ Erreur lors de la correction de ${filePath}:`, error.message);
    return false;
  }
}

// Script principal
function main() {
  console.log('🔧 Correction des imports translationService...');
  
  const srcDir = path.join(__dirname, 'src');
  const vueFiles = findVueFiles(srcDir);
  
  console.log(`📁 ${vueFiles.length} fichiers Vue trouvés`);
  
  let fixedCount = 0;
  
  for (const file of vueFiles) {
    if (fixFile(file)) {
      fixedCount++;
    }
  }
  
  console.log(`\n✨ Correction terminée: ${fixedCount} fichiers modifiés`);
  
  if (fixedCount > 0) {
    console.log('\n🔄 Redémarrage du serveur de développement recommandé');
  }
}

if (require.main === module) {
  main();
}

module.exports = { fixFile, findVueFiles };