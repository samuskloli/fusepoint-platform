const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Configuration
const BASE_URL = 'http://localhost:3002';
const CLIENT_ID = 35;
const AGENT_ID = 36; // Agent qui existe dans la DB

async function testAssignAgent() {
  try {
    console.log('🔍 Test d\'assignation d\'agent');
    console.log('Client ID:', CLIENT_ID);
    console.log('Agent ID:', AGENT_ID);
    
    // Simuler la requête du frontend avec curl
    const curlCommand = `curl -s -X POST ${BASE_URL}/api/client/${CLIENT_ID}/assign-agent \
      -H "Authorization: Bearer test-token" \
      -H "Content-Type: application/json" \
      -d '{"agentId": ${AGENT_ID}}' \
      -w "\nHTTP_CODE:%{http_code}\n"`;
    
    console.log('\n🔍 Commande curl:', curlCommand);
    
    const { stdout, stderr } = await execPromise(curlCommand);
    
    console.log('\n📤 Réponse du serveur:');
    console.log(stdout);
    
    if (stderr) {
      console.log('\n❌ Erreurs:');
      console.log(stderr);
    }
    
  } catch (error) {
    console.error('❌ Erreur lors du test:', error);
  }
}

testAssignAgent();