#!/bin/bash

# =============================================================================
# Script de Basculement d'Environnement
# =============================================================================

set -e

# Couleurs
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Fonction d'aide
show_help() {
    echo "🔄 Script de Basculement d'Environnement Fusepoint"
    echo ""
    echo "Usage: $0 [ENVIRONNEMENT]"
    echo ""
    echo "Environnements disponibles:"
    echo "  dev, development    - Configuration de développement local"
    echo "  prod, production    - Configuration de production"
    echo "  status              - Afficher l'environnement actuel"
    echo "  help                - Afficher cette aide"
    echo ""
    echo "Exemples:"
    echo "  $0 dev              # Basculer vers le développement"
    echo "  $0 production       # Basculer vers la production"
    echo "  $0 status           # Voir l'environnement actuel"
}

# Fonction pour afficher le statut actuel
show_status() {
    echo "📊 Statut de l'environnement actuel:"
    echo "===================================="
    
    if [[ -f ".env" ]]; then
        # Lire les variables importantes
        NODE_ENV=$(grep "^NODE_ENV=" .env 2>/dev/null | cut -d'=' -f2 || echo "non défini")
        VITE_API_URL=$(grep "^VITE_API_URL=" .env 2>/dev/null | cut -d'=' -f2 || echo "non défini")
        FRONTEND_URL=$(grep "^FRONTEND_URL=" .env 2>/dev/null | cut -d'=' -f2 || echo "non défini")
        
        echo "NODE_ENV: $NODE_ENV"
        echo "VITE_API_URL: $VITE_API_URL"
        echo "FRONTEND_URL: $FRONTEND_URL"
        
        # Déterminer l'environnement
        if [[ "$VITE_API_URL" == *"localhost"* ]]; then
            print_info "Environnement détecté: DÉVELOPPEMENT"
        elif [[ "$VITE_API_URL" == *"https://"* ]]; then
            print_info "Environnement détecté: PRODUCTION"
        else
            print_warning "Environnement non déterminé"
        fi
    else
        print_error "Fichier .env non trouvé"
    fi
}

# Fonction pour basculer vers le développement
switch_to_development() {
    print_info "Basculement vers l'environnement de DÉVELOPPEMENT..."
    
    # Sauvegarder la configuration actuelle
    if [[ -f ".env" ]]; then
        cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
        print_info "Configuration actuelle sauvegardée"
    fi
    
    # Copier la configuration de développement
    if [[ -f ".env.development" ]]; then
        cp .env.development .env
        print_success "Configuration de développement activée"
    else
        print_error "Fichier .env.development non trouvé"
        return 1
    fi
    
    # Vérifier la configuration
    print_info "Vérification de la configuration..."
    if ./scripts/validate-env.sh; then
        print_success "Configuration de développement validée"
    else
        print_warning "Configuration avec des avertissements (normal en développement)"
    fi
}

# Fonction pour basculer vers la production
switch_to_production() {
    print_info "Basculement vers l'environnement de PRODUCTION..."
    
    # Avertissement de sécurité
    print_warning "ATTENTION: Basculement vers la production!"
    print_warning "Assurez-vous que toutes les clés et secrets sont corrects."
    
    read -p "Continuer? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Opération annulée"
        return 0
    fi
    
    # Sauvegarder la configuration actuelle
    if [[ -f ".env" ]]; then
        cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
        print_info "Configuration actuelle sauvegardée"
    fi
    
    # Créer la configuration de production
    cat > .env << 'EOF'
# Base de données
DATABASE_URL="mysql://tt3ae_fusepoint:i!sT\$r68!J4LU@tt3ae.myd.infomaniak.com:3306/tt3ae_fusepoint"

# Configuration serveur
NODE_ENV=production
PORT=8080

# URLs avec votre domaine
FRONTEND_URL=https://beta.fusepoint.ch
BASE_URL=https://beta.fusepoint.ch
API_BASE_URL=https://beta.fusepoint.ch/api

# Sécurité
JWT_SECRET=c562c4171abd11ef5a40aa858d7702db810d2adcfdcd64a6e1af8bb4243c28c9
ENCRYPTION_KEY=984e248e20809e0b407a72e42d4e5c91
CORS_ORIGIN=https://beta.fusepoint.ch

# Configuration SMTP Infomaniak
SMTP_HOST=mail.infomaniak.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=info@fusepoint.ch
SMTP_PASS="w3\$a8W!Tf7m_#MF"
EMAIL_FROM=info@fusepoint.ch
EMAIL_FROM_NAME="Fusepoint Hub"
TEST_EMAIL=samuskl@gmail.com

# OpenAI
OPENAI_API_KEY=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

# Configuration OAuth Facebook
FACEBOOK_APP_ID=1242289160417165
FACEBOOK_APP_SECRET=dd54717dd0c9c252d53050d9e4236950

# Configuration OAuth Instagram
INSTAGRAM_APP_ID=your_instagram_app_id
INSTAGRAM_APP_SECRET=your_instagram_app_secret

# Application
APP_NAME="Fusepoint Platform"

# Configuration de sécurité
BCRYPT_ROUNDS=12
SESSION_TIMEOUT=3600000
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_TIME=900000
JWT_EXPIRES_IN=24h
JWT_REFRESH_EXPIRES_IN=7d

# Configuration de limitation de taux
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100

# Configuration de journalisation
LOG_LEVEL=info
LOG_FILE=./logs/app.log

# Configuration Frontend
VITE_API_URL=https://beta.fusepoint.ch/api
VITE_BACKEND_URL=https://beta.fusepoint.ch
EOF
    
    print_success "Configuration de production activée"
    
    # Vérifier la configuration
    print_info "Vérification de la configuration..."
    if ./scripts/validate-env.sh; then
        print_success "Configuration de production validée"
    else
        print_error "Configuration de production invalide!"
        return 1
    fi
}

# Script principal
case "${1:-help}" in
    "dev"|"development")
        switch_to_development
        ;;
    "prod"|"production")
        switch_to_production
        ;;
    "status")
        show_status
        ;;
    "help"|"--help"|"")
        show_help
        ;;
    *)
        print_error "Environnement non reconnu: $1"
        echo ""
        show_help
        exit 1
        ;;
esac