#!/bin/bash

# Script de raccourci pour les commandes administratives Fusepoint
# Usage: ./admin.sh [commande]

# Rediriger vers le script principal
./admin-commands.sh "$@"